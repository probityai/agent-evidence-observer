# Copyright 2026 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

import abc
from enum import Enum
from typing import Optional
from typing import Union

from google.genai import types as genai_types
from pydantic import alias_generators
from pydantic import BaseModel
from pydantic import ConfigDict
from pydantic import Field
from pydantic import field_validator
from pydantic import PrivateAttr
from pydantic import SerializeAsAny
from pydantic.json_schema import SkipJsonSchema
from typing_extensions import TypeAlias

from ..telemetry._token_usage import CACHE_READ_INPUT_TOKENS_MEANING
from ..telemetry._token_usage import CANDIDATE_OUTPUT_TOKENS_MEANING
from ..telemetry._token_usage import INPUT_TOKENS_MEANING
from ..telemetry._token_usage import OUTPUT_TOKENS_MEANING
from ..telemetry._token_usage import PROMPT_INPUT_TOKENS_MEANING
from ..telemetry._token_usage import REASONING_OUTPUT_TOKENS_MEANING
from ..telemetry._token_usage import TOOL_INPUT_TOKENS_MEANING
from ..telemetry._token_usage import TOTAL_TOKENS_MEANING
from .common import EvalBaseModel
from .eval_case import Invocation
from .eval_rubrics import Rubric as Rubric
from .eval_rubrics import RubricScore as RubricScore


class EvalStatus(Enum):
  PASSED = 1
  FAILED = 2
  NOT_EVALUATED = 3
  # Reported for reference-free, informational metrics (e.g. the efficiency
  # metrics): a value was computed and reported, but the metric does not pass
  # or fail an eval case. Distinct from NOT_EVALUATED, which means the metric
  # was not evaluated at all.
  INFORMATIONAL = 4


class PrebuiltMetrics(Enum):
  TOOL_TRAJECTORY_AVG_SCORE = "tool_trajectory_avg_score"

  RESPONSE_EVALUATION_SCORE = "response_evaluation_score"

  RESPONSE_MATCH_SCORE = "response_match_score"

  SAFETY_V1 = "safety_v1"

  FINAL_RESPONSE_MATCH_V2 = "final_response_match_v2"

  RUBRIC_BASED_FINAL_RESPONSE_QUALITY_V1 = (
      "rubric_based_final_response_quality_v1"
  )

  HALLUCINATIONS_V1 = "hallucinations_v1"

  RUBRIC_BASED_TOOL_USE_QUALITY_V1 = "rubric_based_tool_use_quality_v1"

  PER_TURN_USER_SIMULATOR_QUALITY_V1 = "per_turn_user_simulator_quality_v1"

  MULTI_TURN_TASK_SUCCESS_V1 = "multi_turn_task_success_v1"

  MULTI_TURN_TRAJECTORY_QUALITY_V1 = "multi_turn_trajectory_quality_v1"

  MULTI_TURN_TOOL_USE_QUALITY_V1 = "multi_turn_tool_use_quality_v1"

  RUBRIC_BASED_MULTI_TURN_TRAJECTORY_QUALITY_V1 = (
      "rubric_based_multi_turn_trajectory_quality_v1"
  )

  # Efficiency metrics. These are reference-free, informational metrics: they
  # report a value (lower is better) for the user to track their agent's
  # efficiency, and do not pass or fail the eval case.
  TOOL_CALL_COUNT_V1 = "tool_call_count_v1"

  # "inference call" rather than "LLM call", matching the name ADK telemetry
  # publishes this count under. An eval invocation spans a whole turn -- every
  # sub-agent shares the turn's invocation id -- so the quantity lines up with
  # telemetry's per-turn `adk.invoke_workflow.inference_calls` rather than its
  # per-agent counterpart.
  INFERENCE_CALL_COUNT_V1 = "inference_call_count_v1"

  TOKEN_USAGE_V1 = "token_usage_v1"

  INVOCATION_DURATION_V1 = "invocation_duration_v1"


MetricName: TypeAlias = Union[str, PrebuiltMetrics]
Threshold: TypeAlias = float


class JudgeModelOptions(EvalBaseModel):
  """Options for an eval metric's judge model."""

  judge_model: str = Field(
      default="gemini-2.5-flash",
      description=(
          "The judge model to use for evaluation. It can be a model name."
      ),
  )

  judge_model_config: SkipJsonSchema[
      Optional[genai_types.GenerateContentConfig]
  ] = Field(
      default=None,
      description="The configuration for the judge model.",
  )

  num_samples: int = Field(
      default=5,
      ge=1,
      description=(
          "The number of times to sample the model for each invocation"
          " evaluation. Given that models tend to have certain degree of"
          " unreliability to them, we repeatedly sample them with the same"
          " data. These repeated invocation are them aggregated using some"
          " strategy. From experimentation, we have found 5 to be a good"
          " default."
      ),
  )

  parallelism_limit: int = Field(
      default=1,
      ge=1,
      description=(
          "The maximum number of parallel LLM evaluation calls to execute."
      ),
  )


class BaseCriterion(BaseModel):
  """Base criterion to use for an Eval Metric."""

  model_config = ConfigDict(
      alias_generator=alias_generators.to_camel,
      populate_by_name=True,
      extra="allow",
  )

  threshold: Threshold = Field(
      description="The threshold to be used by the metric.",
  )

  include_intermediate_responses_in_final: bool = Field(
      default=False,
      description=(
          "Whether to evaluate the full agent response including intermediate"
          " natural language text (e.g. text emitted before tool calls) in"
          " addition to the final response. By default, only the final"
          " response text is sent to the judge. When True, text from all"
          " intermediate invocation events is concatenated with the final"
          " response before evaluation. This is useful for agents that emit"
          " text both before and after tool calls within a single invocation."
      ),
  )


class LlmAsAJudgeCriterion(BaseCriterion):
  """Criterion when using LLM-As-A-Judge metric."""

  judge_model_options: JudgeModelOptions = Field(
      default_factory=JudgeModelOptions,
      description="Options for the judge model.",
  )


class RubricsBasedCriterion(BaseCriterion):
  """Criterion when using a rubric based metric."""

  judge_model_options: JudgeModelOptions = Field(
      default_factory=JudgeModelOptions,
      description="Options for the judge model.",
  )

  rubrics: list[Rubric] = Field(
      default_factory=list,
      description=(
          "Rubrics to be used by Metric. Not all metrics rely on rubrics, but"
          " metrics like `rubric_based_final_response_quality_v1` do. Metrics"
          " that don't use Rubrics, will just ignore this field, if specified."
          " Metrics that do use rubrics will raise an exception, if they are"
          " not specified."
      ),
  )


class HallucinationsCriterion(BaseCriterion):
  """Criterion to use when evaluating agents response for hallucinations."""

  judge_model_options: JudgeModelOptions = Field(
      default_factory=JudgeModelOptions,
      description="Options for the judge model.",
  )

  evaluate_intermediate_nl_responses: bool = Field(
      default=False,
      description=(
          "Whether any intermediate NL responses should be evaluated"
          " for hallucinations or not. By default, the metric only evaluates"
          " final response from the Agent for hallucinations."
      ),
  )


class ToolTrajectoryCriterion(BaseCriterion):
  """Criterion to use when evaluating agent's tool trajectories with a reference one."""

  class MatchType(Enum):
    """The type of Match between actual and expected tool call trajectories."""

    EXACT = 0
    """Requires a perfect match between the actual and expected tool calls."""

    IN_ORDER = 1
    """Requires the actual tool calls to be in the same order as expected tools,
    with allowance for extra tool calls to have happened.

    This criteria is useful in assuring if certain key actions/tool calls
    occur and in certain order, leaving some scope for other tools calls to
    happen as well.

    Example 1: Set of actual vs expected tool calls that satisfies the criteria:

      Expected tools calls: [T1, T2, T3]
      Actual tool calls: [T1, T1.1, T2, T2.1, T2.2, T3, T3.1]

      This satisfies, as the tools T1, T2 and T3 happened in the "Actual" and in
      the same order.

    Example 2: Set of actual vs expected tool calls that don't satisfy the
    criteria:

      Expected tools calls: [T1, T2, T3, T4]
      Actual tool calls: [T1, T1.1, T2, T2.1, T2.2, T3, T3.1]

      While the tool calls T1, T2 and T3 happened in the "Actual" and in
      the same order as "Expected", but the tool calls T4 is missing.
    """

    ANY_ORDER = 2
    """Requires the actual tool calls to be in the any order as expected tools,
    with allowance for extra tool calls to have happened.

    This criteria is helpful for cases where multiple tool calls about the same
    concept occur, like your agent issues 5 search queries. You don't really
    care the order in which the search queries are issues, till they occur.

    Example 1: Set of actual vs expected tool calls that satisfies the criteria:

      Expected tools calls: [T1, T2, T3]
      Actual tool calls: [T2, T2.1, T1, T1.1, T1.2, T3, T3.1]

      This satisfies, as the tools T1, T2 and T3 happened in the "Actual" and
      are also present in expected. Note that the order is different.

    Example 2: Set of actual vs expected tool calls that don't satisfy the
    criteria:

      Expected tools calls: [T1, T2, T3, T4]
      Actual tool calls: [T1, T1.1, T2, T2.1, T2.2, T3, T3.1]

      While the tool calls T1, T2 and T3 happened in the "Actual" and in
      the same order as "Expected", but the tool calls T4 is missing.
    """

  match_type: MatchType = Field(
      default=MatchType.EXACT,
      description=(
          "The type of Match between actual and expected tool call"
          " trajectories."
      ),
  )

  ignore_args: bool = Field(
      default=False,
      description=(
          "If True, only tool names are compared; arguments are ignored."
      ),
  )

  @field_validator("match_type", mode="before")
  @classmethod
  def _coerce_match_type(cls, value: object) -> object:
    if isinstance(value, cls.MatchType):
      return value
    if isinstance(value, str):
      normalized = value.strip().upper().replace("-", "_").replace(" ", "_")
      if normalized in cls.MatchType.__members__:
        return cls.MatchType[normalized]
    return value


class LlmBackedUserSimulatorCriterion(LlmAsAJudgeCriterion):
  """Criterion for LLM-backed User Simulator Evaluators."""

  stop_signal: str = Field(
      default="</finished>",
      description=(
          "Stop signal to validate the successful completion of a conversation."
          " For optimal performance, this should match the one in the User"
          " Simulator."
      ),
  )


class TokenUsageDetails(EvalBaseModel):
  """Per-type token counts behind a `token_usage_v1` score.

  Reported for every eval, with no configuration. The counts nest rather than
  form a flat list of addends::

      total_tokens
        input_tokens
          prompt_tokens
            cached_tokens
          tool_use_tokens
        output_tokens
          candidates_tokens
          reasoning_tokens

  where each count contains the ones indented under it. `total_tokens` is
  derived from `input_tokens` and `output_tokens` rather than taken from the
  backend's reported total, so it always agrees with the two directions it sums.

  What each count means is defined once, by `google.adk.telemetry._token_usage`,
  and reused here, so an eval breakdown and the telemetry ADK publishes for the
  same run describe the same quantities.

  A field is None when no model call reported that count, meaning the value is
  unavailable (n/a) rather than zero.
  """

  total_tokens: Optional[float] = Field(
      default=None,
      description=TOTAL_TOKENS_MEANING,
  )

  input_tokens: Optional[float] = Field(
      default=None,
      description=INPUT_TOKENS_MEANING,
  )

  prompt_tokens: Optional[float] = Field(
      default=None,
      description=PROMPT_INPUT_TOKENS_MEANING,
  )

  cached_tokens: Optional[float] = Field(
      default=None,
      description=CACHE_READ_INPUT_TOKENS_MEANING,
  )

  tool_use_tokens: Optional[float] = Field(
      default=None,
      description=TOOL_INPUT_TOKENS_MEANING,
  )

  output_tokens: Optional[float] = Field(
      default=None,
      description=OUTPUT_TOKENS_MEANING,
  )

  candidates_tokens: Optional[float] = Field(
      default=None,
      description=CANDIDATE_OUTPUT_TOKENS_MEANING,
  )

  reasoning_tokens: Optional[float] = Field(
      default=None,
      description=REASONING_OUTPUT_TOKENS_MEANING,
  )


class EvalMetric(EvalBaseModel):
  """A metric used to evaluate a particular aspect of an eval case."""

  metric_name: str = Field(
      description="The name of the metric.",
  )

  threshold: Optional[float] = Field(
      default=None,
      description=(
          "This field will be deprecated soon. Please use `criterion` instead."
          " A threshold value. Each metric decides how to interpret this"
          " threshold."
      ),
  )

  criterion: Optional[SerializeAsAny[BaseCriterion]] = Field(
      default=None, description="""Evaluation criterion used by the metric."""
  )

  custom_function_path: Optional[str] = Field(
      default=None,
      description="""Path to custom function, if this is a custom metric.""",
  )

  # The path declared for this metric in the eval config it was built from.
  # Private, so that a metric parsed from an inbound payload cannot carry one:
  # the public field above is settable by whoever built that payload.
  _config_custom_function_path: Optional[str] = PrivateAttr(default=None)


def _get_metric_threshold(eval_metric: EvalMetric) -> float:
  """Returns the configured threshold or rejects an incomplete metric."""
  if eval_metric.criterion is not None:
    return eval_metric.criterion.threshold
  if eval_metric.threshold is not None:
    return eval_metric.threshold
  raise ValueError(
      f"Evaluation metric {eval_metric.metric_name!r} requires a threshold."
  )


class EvalMetricResultDetails(EvalBaseModel):
  rubric_scores: Optional[list[RubricScore]] = Field(
      default=None,
      description=(
          "The scores obtained after applying the rubrics to the Agent's"
          " response."
      ),
  )

  token_usage_details: Optional[TokenUsageDetails] = Field(
      default=None,
      description=(
          "The per-type token counts behind a token usage score. Populated"
          " only by the token usage metric."
      ),
  )


class EvalMetricResult(EvalMetric):
  """The actual computed score/value of a particular EvalMetric."""

  score: Optional[float] = Field(
      default=None,
      description=(
          "Score obtained after evaluating the metric. Optional, as evaluation"
          " might not have happened."
      ),
  )

  eval_status: EvalStatus = Field(description="The status of this evaluation.")

  details: EvalMetricResultDetails = Field(
      default_factory=EvalMetricResultDetails, description=""""""
  )


class EvalMetricResultPerInvocation(EvalBaseModel):
  """Eval metric results per invocation."""

  actual_invocation: Invocation = Field(
      description=(
          "The actual invocation, usually obtained by inferencing the agent."
      )
  )

  expected_invocation: Optional[Invocation] = Field(
      default=None,
      description=(
          "The expected invocation, usually the reference or golden invocation."
      ),
  )

  eval_metric_results: list[EvalMetricResult] = Field(
      default=[],
      description="Eval results for each applicable metric.",
  )


class Interval(EvalBaseModel):
  """Represents a range of numeric values, e.g. [0 ,1] or (2,3) or [-1, 6)."""

  min_value: float = Field(description="The smaller end of the interval.")

  open_at_min: bool = Field(
      default=False,
      description=(
          "The interval is Open on the min end. The default value is False,"
          " which means that we assume that the interval is Closed."
      ),
  )

  max_value: float = Field(description="The larger end of the interval.")

  open_at_max: bool = Field(
      default=False,
      description=(
          "The interval is Open on the max end. The default value is False,"
          " which means that we assume that the interval is Closed."
      ),
  )


class MetricValueInfo(EvalBaseModel):
  """Information about the type of metric value."""

  interval: Optional[Interval] = Field(
      default=None,
      description="The values represented by the metric are of type interval.",
  )


class MetricInfo(EvalBaseModel):
  """Information about the metric that are used for Evals."""

  metric_name: str = Field(description="The name of the metric.")

  description: Optional[str] = Field(
      default=None, description="A 2 to 3 line description of the metric."
  )

  metric_value_info: MetricValueInfo = Field(
      description="Information on the nature of values supported by the metric."
  )

  requires_threshold: bool = Field(
      default=True,
      description=(
          "Whether a threshold must be supplied for this metric to produce a"
          " verdict. A metric that does not require one reports a value, and"
          " an `INFORMATIONAL` status rather than a pass or fail, when no"
          " threshold is configured. Surfaces that ask the user to pick"
          " metrics and set thresholds should skip these."
      ),
  )


class MetricInfoProvider(abc.ABC):
  """Interface for providing MetricInfo."""

  @abc.abstractmethod
  def get_metric_info(self) -> MetricInfo:
    """Returns MetricInfo for a given metric."""
    raise NotImplementedError
