import abc
import asyncio
import io
import shlex
from collections.abc import Awaitable, Callable, Mapping, Sequence
from pathlib import Path, PurePath
from typing import Literal, NoReturn, TypeVar

from typing_extensions import Self

from ...editor import ApplyPatchOperation
from ...run_config import (
    DEFAULT_MAX_LOCAL_DIR_FILE_CONCURRENCY,
    DEFAULT_MAX_MANIFEST_ENTRY_CONCURRENCY,
    SandboxArchiveLimits,
    SandboxConcurrencyLimits,
)
from .._mount_security import redact_mount_error_data, validate_manifest_mount_credential_boundaries
from ..apply_patch import PatchFormat, WorkspaceEditor
from ..entries import BaseEntry
from ..errors import (
    ExecNonZeroError,
    ExecTransportError,
    ExposedPortUnavailableError,
    InvalidManifestPathError,
    MountConfigError,
    PtySessionNotFoundError,
    SandboxError,
    WorkspaceArchiveReadError,
    WorkspaceArchiveWriteError,
    WorkspaceReadNotFoundError,
)
from ..files import FileEntry
from ..manifest import Manifest
from ..materialization import MaterializationResult, MaterializedFile
from ..types import ExecResult, ExposedPortEndpoint, User
from ..util.parse_utils import parse_ls_la
from ..workspace_paths import (
    WorkspacePathPolicy,
    coerce_posix_path,
    posix_path_as_path,
    posix_path_for_error,
    sandbox_path_str,
)
from . import archive_ops, manifest_ops, snapshot_lifecycle
from .dependencies import Dependencies
from .pty_types import PtyExecUpdate
from .runtime_helpers import (
    RESOLVE_WORKSPACE_PATH_HELPER,
    RuntimeHelperScript,
)
from .sandbox_session_state import SandboxSessionState
from .utils import _safe_decode

_PtyEntryT = TypeVar("_PtyEntryT")
_RUNTIME_HELPER_CACHE_KEY_UNSET = object()
_WORKSPACE_ROOT_PROBE_TIMEOUT_S = 10.0
_READ_PATH_PROBE_TIMEOUT_S = 10.0
_READ_PATH_PROBE_SCRIPT = """
# READ_PATH_PROBE_V3
LC_ALL=C
export LC_ALL
path=$1
resolved_path=
symlink_depth=0

resolve_probe_path() {
    if [ "$symlink_depth" -gt 40 ] || [ "${#1}" -gt 4095 ]; then
        return 2
    fi
    if [ "$1" = "/" ]; then
        resolved_path=/
        return 0
    fi

    parent=${1%/*}
    if [ -z "$parent" ] || [ "$parent" = "$1" ]; then
        parent=/
    fi
    resolve_probe_path "$parent" || return 2
    resolved_parent=$resolved_path
    base=${1##*/}
    if [ "${#base}" -gt 255 ]; then
        return 2
    fi
    if [ "$resolved_parent" = "/" ]; then
        candidate=/$base
    else
        candidate=$resolved_parent/$base
    fi

    if [ -L "$candidate" ]; then
        target_with_marker=$(readlink -n "$candidate" && printf .) || return 2
        target=${target_with_marker%.}
        symlink_depth=$((symlink_depth + 1))
        if [ "$symlink_depth" -gt 40 ]; then
            return 2
        fi
        case "$target" in
            /*)
                resolve_probe_path "$target"
                ;;
            *)
                resolve_probe_path "$resolved_parent/$target"
                ;;
        esac
        return $?
    fi

    resolved_path=$candidate
}

resolve_probe_path "$path" || exit 2
path=$resolved_path
candidate=$path
child=

while :; do
    if [ -e "$candidate" ]; then
        if [ "$candidate" = "$path" ]; then
            exit 0
        fi
        if [ ! -d "$candidate" ] || [ ! -x "$candidate" ]; then
            exit 2
        fi
        lookup_result=$(
            find "$child" -prune -print 2>&1 >/dev/null
            lookup_status=$?
            printf '.%s' "$lookup_status"
        )
        lookup_status=${lookup_result##*.}
        lookup_error=${lookup_result%.*}
        if [ "$lookup_status" -eq 1 ]; then
            lookup_error=$(printf %s "$lookup_error")
            case "$lookup_error" in
                *": No such file or directory")
                    exit 1
                    ;;
            esac
        fi
        exit 2
    fi
    if [ "$candidate" = "/" ]; then
        exit 2
    fi
    child=$candidate
    candidate=${candidate%/*}
    if [ -z "$candidate" ]; then
        candidate=/
    fi
done
""".strip()
_WRITE_ACCESS_CHECK_SCRIPT = (
    'target="$1"\n'
    'if [ -e "$target" ]; then\n'
    '    [ -f "$target" ] && [ -w "$target" ]\n'
    "    exit $?\n"
    "fi\n"
    'parent=$(dirname "$target")\n'
    'while [ ! -e "$parent" ]; do\n'
    '    next=$(dirname "$parent")\n'
    '    if [ "$next" = "$parent" ]; then\n'
    "        exit 1\n"
    "    fi\n"
    '    parent="$next"\n'
    "done\n"
    '[ -d "$parent" ] && [ -w "$parent" ] && [ -x "$parent" ]\n'
)
_MKDIR_ACCESS_CHECK_SCRIPT = (
    'target="$1"\n'
    'parents="$2"\n'
    'if [ -e "$target" ] || [ -L "$target" ]; then\n'
    '    [ -d "$target" ] && [ -x "$target" ]\n'
    "    exit $?\n"
    "fi\n"
    'parent=$(dirname "$target")\n'
    'if [ "$parents" = "1" ]; then\n'
    '    while [ ! -e "$parent" ]; do\n'
    '        next=$(dirname "$parent")\n'
    '        if [ "$next" = "$parent" ]; then\n'
    "            exit 1\n"
    "        fi\n"
    '        parent="$next"\n'
    "    done\n"
    "fi\n"
    '[ -d "$parent" ] && [ -w "$parent" ] && [ -x "$parent" ]\n'
)
_RM_ACCESS_CHECK_SCRIPT = (
    'target="$1"\n'
    'recursive="$2"\n'
    'if [ ! -e "$target" ] && [ ! -L "$target" ]; then\n'
    '    [ "$recursive" = "1" ]\n'
    "    exit $?\n"
    "fi\n"
    'parent=$(dirname "$target")\n'
    '[ -d "$parent" ] && [ -w "$parent" ] && [ -x "$parent" ]\n'
)


class BaseSandboxSession(abc.ABC):
    state: SandboxSessionState
    _dependencies: Dependencies | None = None
    _dependencies_closed: bool = False
    _runtime_persist_workspace_skip_relpaths: set[Path] | None = None
    _pre_stop_hooks: list[Callable[[], Awaitable[None]]] | None = None
    _pre_stop_hooks_ran: bool = False
    _pre_stop_hooks_failed: bool = False
    _pre_stop_hooks_lock: asyncio.Lock | None = None
    _aclose_lock: asyncio.Lock | None = None
    _runtime_helpers_installed: set[PurePath] | None = None
    _runtime_helper_cache_key: object = _RUNTIME_HELPER_CACHE_KEY_UNSET
    _workspace_path_policy_cache: (
        tuple[str, tuple[tuple[str, bool, str | None], ...], WorkspacePathPolicy] | None
    ) = None
    # True when start() is reusing a backend whose workspace files may still be present.
    # This controls whether start() can avoid a full manifest apply for non-snapshot resumes.
    _start_workspace_state_preserved: bool = False
    # True when start() is reusing a backend whose OS users and groups may still be present.
    # This controls whether snapshot restore needs to reprovision manifest-managed accounts.
    _start_system_state_preserved: bool = False
    # Snapshot of serialized workspace readiness after backend startup/reconnect.
    # Providers may set this to True during start only after a preserved-backend probe succeeds.
    _start_workspace_root_ready: bool | None = None
    _max_manifest_entry_concurrency: int | None = DEFAULT_MAX_MANIFEST_ENTRY_CONCURRENCY
    _max_local_dir_file_concurrency: int | None = DEFAULT_MAX_LOCAL_DIR_FILE_CONCURRENCY
    _archive_limits: SandboxArchiveLimits | None = None

    def _runtime_has_protected_mount_authority(self) -> bool:
        """Return whether SDK-owned runtime state contains live mount authority."""

        return False

    @redact_mount_error_data
    async def start(self) -> None:
        from .._mount_security import validate_manifest_mount_credential_boundaries

        validate_manifest_mount_credential_boundaries(
            self.state.manifest,
            provider_backend_id=self.state.type,
        )
        try:
            await self._ensure_backend_started()
            self._start_workspace_root_ready = self.state.workspace_root_ready
            await self._probe_workspace_root_for_preserved_resume()
            await self._prepare_backend_workspace()
            await self._ensure_runtime_helpers()
            await self._start_workspace()
        except Exception as e:
            await self._after_start_failed()
            wrapped = self._wrap_start_error(e)
            if wrapped is e:
                raise
            raise wrapped from e
        await self._after_start()
        self.state.workspace_root_ready = True

    def _set_concurrency_limits(self, limits: SandboxConcurrencyLimits) -> None:
        limits.validate()
        self._max_manifest_entry_concurrency = limits.manifest_entries
        self._max_local_dir_file_concurrency = limits.local_dir_files

    def _set_archive_limits(self, limits: SandboxArchiveLimits | None) -> None:
        if limits is not None:
            limits.validate()
        self._archive_limits = limits

    async def _ensure_backend_started(self) -> None:
        """Start, reconnect, or recreate the backend before workspace setup runs."""

        return

    async def _prepare_backend_workspace(self) -> None:
        """Prepare provider-specific workspace prerequisites before manifest or snapshot work."""

        return

    async def _probe_workspace_root_for_preserved_resume(self) -> bool:
        """Probe whether a preserved backend already has a usable workspace root."""

        if not self._workspace_state_preserved_on_start() or self._start_workspace_root_ready:
            return self._can_reuse_preserved_workspace_on_resume()

        try:
            result = await self.exec(
                "test",
                "-d",
                self.state.manifest.root,
                timeout=_WORKSPACE_ROOT_PROBE_TIMEOUT_S,
                shell=False,
            )
        except Exception:
            return False

        if not result.ok():
            return False

        self._mark_workspace_root_ready_from_probe()
        return True

    def _mark_workspace_root_ready_from_probe(self) -> None:
        """Record that the preserved-backend workspace root was proven ready."""

        self.state.workspace_root_ready = True
        self._start_workspace_root_ready = True

    def _set_start_state_preserved(self, workspace: bool, *, system: bool | None = None) -> None:
        """Record whether this start begins with preserved backend state."""

        self._start_workspace_state_preserved = workspace
        self._start_system_state_preserved = workspace if system is None else system

    def _workspace_state_preserved_on_start(self) -> bool:
        """Return whether start begins with previously persisted workspace state."""

        return self._start_workspace_state_preserved

    def _system_state_preserved_on_start(self) -> bool:
        """Return whether start begins with previously provisioned OS/user state."""

        return self._start_system_state_preserved

    async def _start_workspace(self) -> None:
        """Restore snapshot or apply manifest state after backend startup is complete."""

        validate_manifest_mount_credential_boundaries(
            self.state.manifest,
            provider_backend_id=self.state.type,
        )
        if await self.state.snapshot.restorable(dependencies=self.dependencies):
            can_reuse_workspace = await self._can_reuse_restorable_snapshot_workspace()
            if can_reuse_workspace:
                # The preserved workspace already matches the snapshot, so only rebuild ephemeral
                # manifest state that intentionally was not persisted.
                await self._reapply_ephemeral_manifest_on_resume()
            else:
                # Fresh workspaces and drifted preserved workspaces both need the durable snapshot
                # restored before ephemeral state is rebuilt.
                await self._restore_snapshot_and_reapply_ephemeral_on_resume()
        elif self._can_reuse_preserved_workspace_on_resume():
            # There is no durable snapshot to restore, but a reconnected backend may still need
            # ephemeral mounts/files refreshed without reapplying the full manifest.
            await self._reapply_ephemeral_manifest_on_resume()
        else:
            # A fresh backend without a restorable snapshot needs the full manifest materialized.
            await self._apply_manifest(
                provision_accounts=self.should_provision_manifest_accounts_on_resume()
            )

    async def _restore_snapshot_and_reapply_ephemeral_on_resume(self) -> None:
        await self._restore_snapshot_into_workspace_on_resume()
        if self.should_provision_manifest_accounts_on_resume():
            await self.provision_manifest_accounts()
        await self._reapply_ephemeral_manifest_on_resume()

    async def _can_reuse_restorable_snapshot_workspace(self) -> bool:
        """Return whether a restorable snapshot can be skipped for this start."""

        if not self._can_reuse_preserved_workspace_on_resume():
            return False
        is_running = await self.running()
        return await self._can_skip_snapshot_restore_on_resume(is_running=is_running)

    def _can_reuse_preserved_workspace_on_resume(self) -> bool:
        """Return whether preserved workspace state is proven safe to reuse."""

        workspace_root_ready = self._start_workspace_root_ready
        if workspace_root_ready is None:
            workspace_root_ready = self.state.workspace_root_ready
        return self._workspace_state_preserved_on_start() and workspace_root_ready

    async def _after_start(self) -> None:
        """Run provider bookkeeping after workspace setup succeeds."""

        return

    async def _after_start_failed(self) -> None:
        """Run provider bookkeeping after workspace setup fails."""

        return

    def _wrap_start_error(self, error: Exception) -> Exception:
        """Return a provider-specific start error, or the original error."""

        return error

    @redact_mount_error_data
    async def stop(self) -> None:
        """
        Persist/snapshot the workspace.

        Note: `stop()` is intentionally persistence-only. Sandboxes that need to tear down
        sandbox resources (Docker containers, remote sessions, etc.) should implement
        `shutdown()` instead.
        """
        validate_manifest_mount_credential_boundaries(
            self.state.manifest,
            provider_backend_id=self.state.type,
        )
        try:
            try:
                await self._before_stop()
                await self._persist_snapshot()
            except Exception as e:
                wrapped = self._wrap_stop_error(e)
                if wrapped is e:
                    raise
                raise wrapped from e
        finally:
            await self._after_stop()

    async def _before_stop(self) -> None:
        """Run transient process cleanup before snapshot persistence."""

        await self.pty_terminate_all()

    async def _persist_snapshot(self) -> None:
        """Persist/snapshot the workspace."""

        await snapshot_lifecycle.persist_snapshot(self)

    def _wrap_stop_error(self, error: Exception) -> Exception:
        """Return a provider-specific stop error, or the original error."""

        return error

    async def _after_stop(self) -> None:
        """Run provider bookkeeping after stop finishes or fails."""

        return

    def supports_docker_volume_mounts(self) -> bool:
        """Return whether this backend attaches Docker volume mounts before manifest apply."""

        return False

    def supports_pty(self) -> bool:
        return False

    @redact_mount_error_data
    async def shutdown(self) -> None:
        """
        Tear down sandbox resources (best-effort).

        Default is a no-op. Sandbox-specific sessions (e.g. Docker) should override.
        """
        await self._before_shutdown()
        await self._shutdown_backend()
        await self._after_shutdown()

    async def _before_shutdown(self) -> None:
        """Run transient process cleanup before backend shutdown."""

        await self.pty_terminate_all()

    async def _shutdown_backend(self) -> None:
        """Tear down provider-specific backend resources."""

        return

    async def _after_shutdown(self) -> None:
        """Run provider bookkeeping after backend shutdown."""

        return

    async def _terminate_ambiguous_mount_transition(self) -> None:
        """Make a session unusable after a mount transition has an unknown outcome."""

        await self.shutdown()

    async def __aenter__(self) -> Self:
        await self.start()
        return self

    @redact_mount_error_data
    async def aclose(self) -> None:
        """Run the session cleanup lifecycle outside of ``async with``.

        This performs the same session-owned cleanup as ``__aexit__()``: persist/snapshot the
        workspace via ``stop()``, tear down session resources via ``shutdown()``, and close
        session-scoped dependencies. If the session came from a sandbox client, call the client's
        ``delete()`` separately for backend-specific deletion such as removing a Docker container
        or deleting a temporary host workspace.
        """

        lock = self._aclose_lock
        if lock is None:
            lock = asyncio.Lock()
            self._aclose_lock = lock
        async with lock:
            await self._aclose_impl()

    async def _aclose_impl(self) -> None:
        cleanup_error: BaseException | None = None
        try:
            await self.run_pre_stop_hooks()
        except BaseException as exc:
            cleanup_error = exc
        try:
            if cleanup_error is None and not self._pre_stop_hooks_failed:
                await self.stop()
            await self.shutdown()
        except BaseException as exc:
            if cleanup_error is None:
                cleanup_error = exc
        finally:
            try:
                await self._aclose_dependencies()
            except BaseException as exc:
                if cleanup_error is None:
                    cleanup_error = exc
        if cleanup_error is not None:
            raise cleanup_error

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc: BaseException | None,
        tb: object | None,
    ) -> None:
        await self.aclose()

    @property
    def dependencies(self) -> Dependencies:
        dependencies = self._dependencies
        if dependencies is None:
            dependencies = Dependencies()
            self._dependencies = dependencies
            self._dependencies_closed = False
        return dependencies

    def set_dependencies(self, dependencies: Dependencies | None) -> None:
        if dependencies is None:
            return
        self._dependencies = dependencies
        self._dependencies_closed = False

    def register_pre_stop_hook(self, hook: Callable[[], Awaitable[None]]) -> None:
        """Register an async hook to run once before the session workspace is persisted."""

        hooks = self._pre_stop_hooks
        if hooks is None:
            hooks = []
            self._pre_stop_hooks = hooks
        hooks.append(hook)
        self._pre_stop_hooks_ran = False

    @redact_mount_error_data
    async def run_pre_stop_hooks(self) -> None:
        """Run registered pre-stop hooks once before workspace persistence."""

        lock = self._pre_stop_hooks_lock
        if lock is None:
            lock = asyncio.Lock()
            self._pre_stop_hooks_lock = lock
        async with lock:
            hooks = self._pre_stop_hooks
            if hooks is None or self._pre_stop_hooks_ran:
                return
            self._pre_stop_hooks_ran = True
            cleanup_error: BaseException | None = None
            for hook in hooks:
                try:
                    await hook()
                except BaseException as exc:
                    if cleanup_error is None:
                        cleanup_error = exc
            if cleanup_error is not None:
                self._pre_stop_hooks_failed = True
                raise cleanup_error

    async def _run_pre_stop_hooks(self) -> None:
        await self.run_pre_stop_hooks()

    async def _aclose_dependencies(self) -> None:
        dependencies = self._dependencies
        if dependencies is None or self._dependencies_closed:
            return
        self._dependencies_closed = True
        await dependencies.aclose()

    @staticmethod
    def _workspace_relpaths_overlap(lhs: Path, rhs: Path) -> bool:
        return lhs == rhs or lhs in rhs.parents or rhs in lhs.parents

    def _mount_relpaths_within_workspace(self) -> set[Path]:
        root = self._workspace_root_path()
        mount_relpaths: set[Path] = set()
        for _mount_entry, mount_path in self.state.manifest.mount_targets():
            try:
                mount_relpaths.add(mount_path.relative_to(root))
            except ValueError:
                continue
        return mount_relpaths

    def _overlapping_mount_relpaths(self, rel_path: Path) -> set[Path]:
        return {
            mount_relpath
            for mount_relpath in self._mount_relpaths_within_workspace()
            if self._workspace_relpaths_overlap(rel_path, mount_relpath)
        }

    def _native_snapshot_requires_tar_fallback(self) -> bool:
        for mount_entry, _mount_path in self.state.manifest.mount_targets():
            if not mount_entry.mount_strategy.supports_native_snapshot_detach(mount_entry):
                return True
        return False

    def register_persist_workspace_skip_path(self, path: Path | str) -> Path:
        """Exclude a runtime-created workspace path from future workspace snapshots.

        Use this for session side effects that are not part of durable workspace state, such as
        generated mount config or ephemeral sink output.
        """

        rel_path = Manifest._coerce_rel_path(path)
        Manifest._validate_rel_path(rel_path)
        if rel_path in (Path(""), Path(".")):
            raise ValueError("Persist workspace skip paths must target a concrete relative path.")
        overlapping_mounts = self._overlapping_mount_relpaths(rel_path)
        if overlapping_mounts:
            overlapping_mount = min(overlapping_mounts, key=lambda p: (len(p.parts), p.as_posix()))
            raise MountConfigError(
                message="persist workspace skip path must not overlap mount path",
                context={
                    "skip_path": rel_path.as_posix(),
                    "mount_path": overlapping_mount.as_posix(),
                },
            )

        if self._runtime_persist_workspace_skip_relpaths is None:
            self._runtime_persist_workspace_skip_relpaths = set()
        self._runtime_persist_workspace_skip_relpaths.add(rel_path)
        return rel_path

    def _persist_workspace_skip_relpaths(self) -> set[Path]:
        skip_paths = set(self.state.manifest.ephemeral_persistence_paths())
        if self._runtime_persist_workspace_skip_relpaths:
            skip_paths.update(self._runtime_persist_workspace_skip_relpaths)
        return skip_paths

    @redact_mount_error_data
    async def exec(
        self,
        *command: str | Path,
        timeout: float | None = None,
        shell: bool | list[str] = True,
        user: str | User | None = None,
    ) -> ExecResult:
        """Execute a command inside the session.

        :param command: Command and args (will be stringified).
        :param timeout: Optional wall-clock timeout in seconds.
        :param shell: Whether to run this command in a shell. If ``True`` is provided,
            the command will be run prefixed by ``sh -lc``. A custom shell prefix may be used
            by providing a list.

        :returns: An ``ExecResult`` containing stdout/stderr and exit code.

        :raises TimeoutError: If the sandbox cannot complete within `timeout`.
        """

        sanitized_command = self._prepare_exec_command(*command, shell=shell, user=user)
        return await self._exec_internal(*sanitized_command, timeout=timeout)

    @redact_mount_error_data
    async def resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
        self._assert_exposed_port_configured(port)
        return await self._resolve_exposed_port(port)

    def _assert_exposed_port_configured(self, port: int) -> None:
        if port not in self.state.exposed_ports:
            raise ExposedPortUnavailableError(
                port=port,
                exposed_ports=self.state.exposed_ports,
                reason="not_configured",
            )

    def _prepare_exec_command(
        self,
        *command: str | Path,
        shell: bool | list[str],
        user: str | User | None,
    ) -> list[str]:
        sanitized_command = [str(c) for c in command]

        if shell:
            joined = (
                sanitized_command[0]
                if len(sanitized_command) == 1
                else shlex.join(sanitized_command)
            )
            if isinstance(shell, list):
                sanitized_command = shell + [joined]
            else:
                sanitized_command = ["sh", "-lc", joined]

        if user:
            if isinstance(user, User):
                user = user.name

            assert isinstance(user, str)

            sanitized_command = ["sudo", "-u", user, "--"] + sanitized_command

        return sanitized_command

    def _resolve_pty_session_entry(
        self, *, pty_processes: Mapping[int, _PtyEntryT], session_id: int
    ) -> _PtyEntryT:
        entry = pty_processes.get(session_id)
        if entry is None:
            raise PtySessionNotFoundError(session_id=session_id)
        return entry

    async def pty_exec_start(
        self,
        *command: str | Path,
        timeout: float | None = None,
        shell: bool | list[str] = True,
        user: str | User | None = None,
        tty: bool = False,
        yield_time_s: float | None = None,
        max_output_tokens: int | None = None,
    ) -> PtyExecUpdate:
        _ = (command, timeout, shell, user, tty, yield_time_s, max_output_tokens)
        raise NotImplementedError("PTY execution is not supported by this sandbox session")

    async def pty_write_stdin(
        self,
        *,
        session_id: int,
        chars: str,
        yield_time_s: float | None = None,
        max_output_tokens: int | None = None,
    ) -> PtyExecUpdate:
        _ = (session_id, chars, yield_time_s, max_output_tokens)
        raise NotImplementedError("PTY execution is not supported by this sandbox session")

    async def pty_terminate_all(self) -> None:
        return

    @abc.abstractmethod
    async def _exec_internal(
        self,
        *command: str | Path,
        timeout: float | None = None,
    ) -> ExecResult: ...

    async def _resolve_exposed_port(self, port: int) -> ExposedPortEndpoint:
        raise ExposedPortUnavailableError(
            port=port,
            exposed_ports=self.state.exposed_ports,
            reason="backend_unavailable",
            context={"backend": type(self).__name__},
        )

    def _runtime_helpers(self) -> tuple[RuntimeHelperScript, ...]:
        return ()

    def _current_runtime_helper_cache_key(self) -> object | None:
        return None

    def _sync_runtime_helper_install_cache(self) -> None:
        current_key = self._current_runtime_helper_cache_key()
        cached_key = self._runtime_helper_cache_key
        if cached_key is _RUNTIME_HELPER_CACHE_KEY_UNSET:
            self._runtime_helper_cache_key = current_key
            return
        if cached_key != current_key:
            self._runtime_helpers_installed = None
            self._runtime_helper_cache_key = current_key

    async def _ensure_runtime_helper_installed(self, helper: RuntimeHelperScript) -> PurePath:
        self._sync_runtime_helper_install_cache()
        installed = self._runtime_helpers_installed
        if installed is None:
            installed = set()
            self._runtime_helpers_installed = installed

        install_path = helper.install_path
        if install_path in installed:
            probe = await self.exec(*helper.present_command(), shell=False)
            if probe.ok():
                return install_path
            self._sync_runtime_helper_install_cache()
            installed = self._runtime_helpers_installed
            if installed is None:
                installed = set()
                self._runtime_helpers_installed = installed
            installed.discard(install_path)

        result = await self.exec(*helper.install_command(), shell=False)
        if not result.ok():
            raise ExecNonZeroError(
                result,
                command=("install_runtime_helper", str(install_path)),
            )

        self._sync_runtime_helper_install_cache()
        installed = self._runtime_helpers_installed
        if installed is None:
            installed = set()
            self._runtime_helpers_installed = installed
        installed.add(install_path)
        return install_path

    async def _ensure_runtime_helpers(self) -> None:
        for helper in self._runtime_helpers():
            await self._ensure_runtime_helper_installed(helper)

    def _workspace_path_policy(self) -> WorkspacePathPolicy:
        root = self.state.manifest.root
        grants_key = tuple(
            (grant.path, grant.read_only, grant.host_path)
            for grant in self.state.manifest.extra_path_grants
        )
        cached = self._workspace_path_policy_cache
        if cached is not None and cached[0] == root and cached[1] == grants_key:
            return cached[2]

        policy = WorkspacePathPolicy(
            root=root,
            extra_path_grants=self.state.manifest.extra_path_grants,
        )
        self._workspace_path_policy_cache = (root, grants_key, policy)
        return policy

    def _workspace_root_path(self) -> Path:
        return posix_path_as_path(self._workspace_path_policy().sandbox_root())

    async def _validate_path_access(self, path: Path | str, *, for_write: bool = False) -> Path:
        return self.normalize_path(path, for_write=for_write)

    async def _validate_remote_path_access(
        self,
        path: Path | str,
        *,
        for_write: bool = False,
        recursive_remove: bool = False,
    ) -> Path:
        """Validate an SDK file path against the remote sandbox filesystem before IO.

        The returned path is the normalized workspace path, not the resolved realpath. This keeps
        safe leaf symlink operations working normally, such as removing a symlink instead of its
        target, while still rejecting paths whose resolved remote target escapes all allowed roots.
        """

        path_policy = self._workspace_path_policy()
        root = path_policy.sandbox_root()
        workspace_path = path_policy.normalize_sandbox_path(path, for_write=for_write)
        original_path = coerce_posix_path(path)
        access_mode = "2" if recursive_remove else "1" if for_write else "0"
        helper_path = await self._ensure_runtime_helper_installed(RESOLVE_WORKSPACE_PATH_HELPER)
        extra_grant_args = tuple(
            arg
            for root, read_only in path_policy.extra_path_grant_rules()
            for arg in (root.as_posix(), "1" if read_only else "0")
        )
        command = (
            str(helper_path),
            root.as_posix(),
            workspace_path.as_posix(),
            access_mode,
            *extra_grant_args,
        )
        result = await self.exec(*command, shell=False)
        if result.ok():
            resolved = result.stdout.decode("utf-8", errors="replace").strip()
            if resolved:
                # Preserve the requested workspace path so leaf symlinks keep their normal
                # semantics while the remote realpath check still enforces path confinement.
                return posix_path_as_path(workspace_path)
            raise ExecTransportError(
                command=(
                    "resolve_workspace_path",
                    root.as_posix(),
                    workspace_path.as_posix(),
                    access_mode,
                    *extra_grant_args,
                ),
                context={
                    "reason": "empty_stdout",
                    "exit_code": result.exit_code,
                    "stdout": "",
                    "stderr": result.stderr.decode("utf-8", errors="replace"),
                },
            )

        reason: Literal["absolute", "escape_root"] = (
            "absolute" if original_path.is_absolute() else "escape_root"
        )
        if result.exit_code == 111:
            raise InvalidManifestPathError(
                rel=original_path.as_posix(),
                reason=reason,
                context={
                    "resolved_path": result.stderr.decode("utf-8", errors="replace").strip(),
                },
            )
        if result.exit_code == 113:
            raise ValueError(result.stderr.decode("utf-8", errors="replace").strip())
        if result.exit_code == 114:
            stderr = result.stderr.decode("utf-8", errors="replace")
            context: dict[str, object] = {"reason": "read_only_extra_path_grant"}
            for line in stderr.splitlines():
                if line.startswith("read-only extra path grant: "):
                    context["grant_path"] = line.removeprefix("read-only extra path grant: ")
                elif line.startswith("resolved path: "):
                    context["resolved_path"] = line.removeprefix("resolved path: ")
            raise WorkspaceArchiveWriteError(
                path=posix_path_for_error(workspace_path), context=context
            )
        raise ExecNonZeroError(
            result,
            command=(
                "resolve_workspace_path",
                root.as_posix(),
                workspace_path.as_posix(),
                access_mode,
                *extra_grant_args,
            ),
        )

    @abc.abstractmethod
    async def read(self, path: Path, *, user: str | User | None = None) -> io.IOBase:
        """Read a file from the session's workspace.

        :param path: Absolute path in the container or path relative to the
                workspace root.
        :param user: Optional sandbox user to perform the read as.
        :returns: A readable file-like object.
        :raises: FileNotFoundError: If the path does not exist.
        """

    async def read_bounded(self, path: Path, *, max_bytes: int) -> bytes:
        """Read a prefix of at most ``max_bytes`` bytes.

        Uses the session identity and the same path scope as ``read(path)``.
        A result of exactly ``max_bytes`` bytes does not indicate EOF. Backends
        provided by the SDK bound acquisition from the source. For compatibility,
        custom backends inherit a fallback that consumes and closes the stream
        returned by ``read()``. That fallback cannot bound any data acquired inside
        ``read()`` before it returns. Override ``_read_bounded`` to provide that
        guarantee. Encoded transports may reject responses exceeding their bounded
        framing budget. Failures use payload-free ``WorkspaceArchiveReadError``
        diagnostics.
        """
        if max_bytes <= 0:
            raise ValueError("max_bytes must be positive")
        # Raise outside the handler: provider exceptions may retain response bodies.
        reason = "bounded_read_failed"
        retryable: bool | None = None
        missing = False
        try:
            return await self._read_bounded(path, max_bytes=max_bytes)
        except (FileNotFoundError, WorkspaceReadNotFoundError):
            missing = True
        except SandboxError as error:
            retryable = error.retryable
            if error.context.get("reason") == "bounded_read_wire_limit":
                reason = "bounded_read_wire_limit"
        except Exception:
            # Discard payload-bearing provider diagnostics at this boundary.
            reason = "bounded_read_failed"
        if missing:
            raise WorkspaceReadNotFoundError(path=path)
        raise WorkspaceArchiveReadError(path=path, context={"reason": reason}, retryable=retryable)

    async def _read_bounded(self, path: Path, *, max_bytes: int) -> bytes:
        stream = await self.read(path)
        try:
            result = bytearray()
            while len(result) < max_bytes:
                remaining = max_bytes - len(result)
                payload = stream.read(remaining)
                if not payload:
                    break
                chunk = payload.encode("utf-8") if isinstance(payload, str) else bytes(payload)
                result.extend(chunk[:remaining])
            return bytes(result)
        finally:
            stream.close()

    @abc.abstractmethod
    async def write(
        self,
        path: Path,
        data: io.IOBase,
        *,
        user: str | User | None = None,
    ) -> None:
        """Write a file into the session's workspace.

        :param path: Absolute path in the container or path relative to the
                workspace root.
        :param data: A file-like object positioned at the start of the payload.
        :param user: Optional sandbox user to perform the write as.
        """

    async def _write_new_file(
        self,
        path: Path,
        data: io.IOBase,
        *,
        user: str | User | None = None,
    ) -> None:
        """Backend hook for apply_patch creation.

        The default retains the provider's existing mkdir/write semantics. UnixLocal
        overrides this hook to claim the leaf exclusively; other backends need a native
        primitive before they can offer the same guarantee.
        """
        target = self.normalize_path(path)
        await self.mkdir(target.parent, parents=True, user=user)
        await self.write(target, data, user=user)

    async def _check_read_with_exec(
        self, path: Path | str, *, user: str | User | None = None
    ) -> Path:
        workspace_path = await self._validate_path_access(path)
        path_arg = sandbox_path_str(workspace_path)
        cmd = ("sh", "-lc", '[ -r "$1" ]', "sh", path_arg)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            await self._raise_read_error_from_exec(
                path=posix_path_as_path(coerce_posix_path(path)),
                workspace_path=workspace_path,
                command=("sh", "-lc", "<read_access_check>", path_arg),
                result=result,
                user=user,
            )
        return workspace_path

    async def _raise_read_error_from_exec(
        self,
        *,
        path: Path,
        workspace_path: Path,
        command: Sequence[str | Path],
        result: ExecResult,
        user: str | User | None = None,
    ) -> NoReturn:
        context: dict[str, object] = {
            "command": [str(part) for part in command],
            "stdout_bytes": len(result.stdout),
            "stderr": _safe_decode(result.stderr, max_chars=4096),
        }
        if result.exit_code != 1:
            raise WorkspaceArchiveReadError(path=path, context=context)

        workspace_path_arg = sandbox_path_str(workspace_path)
        try:
            probe_result = await self.exec(
                "sh",
                "-c",
                _READ_PATH_PROBE_SCRIPT,
                "sh",
                workspace_path_arg,
                timeout=_READ_PATH_PROBE_TIMEOUT_S,
                shell=False,
                user=user,
            )
        except Exception as e:
            raise WorkspaceArchiveReadError(path=path, context=context, cause=e) from e

        context["existence_probe_exit_code"] = probe_result.exit_code
        context["existence_probe_stdout_bytes"] = len(probe_result.stdout)
        context["existence_probe_stderr"] = _safe_decode(probe_result.stderr, max_chars=4096)
        if probe_result.exit_code == 1:
            raise WorkspaceReadNotFoundError(path=path, context=context)
        raise WorkspaceArchiveReadError(path=path, context=context)

    async def _check_write_with_exec(
        self, path: Path | str, *, user: str | User | None = None
    ) -> Path:
        workspace_path = await self._validate_path_access(path, for_write=True)
        path_arg = sandbox_path_str(workspace_path)
        cmd = ("sh", "-lc", _WRITE_ACCESS_CHECK_SCRIPT, "sh", path_arg)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise WorkspaceArchiveWriteError(
                path=workspace_path,
                context={
                    "command": ["sh", "-lc", "<write_access_check>", path_arg],
                    "stdout": result.stdout.decode("utf-8", errors="replace"),
                    "stderr": result.stderr.decode("utf-8", errors="replace"),
                },
            )
        return workspace_path

    async def _check_mkdir_with_exec(
        self,
        path: Path | str,
        *,
        parents: bool = False,
        user: str | User | None = None,
    ) -> Path:
        workspace_path = await self._validate_path_access(path, for_write=True)
        parents_flag = "1" if parents else "0"
        path_arg = sandbox_path_str(workspace_path)
        cmd = ("sh", "-lc", _MKDIR_ACCESS_CHECK_SCRIPT, "sh", path_arg, parents_flag)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise WorkspaceArchiveWriteError(
                path=workspace_path,
                context={
                    "command": [
                        "sh",
                        "-lc",
                        "<mkdir_access_check>",
                        path_arg,
                        parents_flag,
                    ],
                    "stdout": result.stdout.decode("utf-8", errors="replace"),
                    "stderr": result.stderr.decode("utf-8", errors="replace"),
                },
            )
        return workspace_path

    async def _check_rm_with_exec(
        self,
        path: Path | str,
        *,
        recursive: bool = False,
        user: str | User | None = None,
    ) -> Path:
        workspace_path = await self._validate_path_access(path, for_write=True)
        recursive_flag = "1" if recursive else "0"
        path_arg = sandbox_path_str(workspace_path)
        cmd = ("sh", "-lc", _RM_ACCESS_CHECK_SCRIPT, "sh", path_arg, recursive_flag)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise WorkspaceArchiveWriteError(
                path=workspace_path,
                context={
                    "command": [
                        "sh",
                        "-lc",
                        "<rm_access_check>",
                        path_arg,
                        recursive_flag,
                    ],
                    "stdout": result.stdout.decode("utf-8", errors="replace"),
                    "stderr": result.stderr.decode("utf-8", errors="replace"),
                },
            )
        return workspace_path

    @abc.abstractmethod
    async def running(self) -> bool:
        """
        :returns: whether the underlying sandbox is currently running.
        """

    @abc.abstractmethod
    async def persist_workspace(self) -> io.IOBase:
        """Serialize the session's workspace into a byte stream.

        :returns: A readable byte stream representing the workspace contents.
            Portable tar streams must use workspace-relative member paths rather than
            embedding the source backend's workspace root directory.
        """

    @abc.abstractmethod
    async def hydrate_workspace(self, data: io.IOBase) -> None:
        """Populate the session's workspace from a serialized byte stream.

        :param data: A readable byte stream as produced by `persist_workspace`.
            Portable tar streams are extracted underneath this session's workspace root.
        """

    async def ls(
        self,
        path: Path | str,
        *,
        user: str | User | None = None,
    ) -> list[FileEntry]:
        """List directory contents.

        :param path: Path to list.
        :param user: Optional sandbox user to list as.
        :returns: A list of `FileEntry` objects.
        """
        path = await self._validate_path_access(path)

        path_arg = sandbox_path_str(path)
        cmd = ("ls", "-la", "--", path_arg)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise ExecNonZeroError(result, command=cmd)

        return parse_ls_la(result.stdout.decode("utf-8", errors="replace"), base=path_arg)

    async def rm(
        self,
        path: Path | str,
        *,
        recursive: bool = False,
        user: str | User | None = None,
    ) -> None:
        """Remove a file or directory.

        :param path: Path to remove.
        :param recursive: If true, remove directories recursively.
        :param user: Optional sandbox user to remove as.
        """
        path = await self._validate_path_access(path, for_write=True)

        cmd: list[str] = ["rm"]
        if recursive:
            if any(grant.read_only for grant in self.state.manifest.extra_path_grants):
                await self._validate_remote_path_access(path, for_write=True, recursive_remove=True)
            cmd.append("-rf")
        cmd.extend(["--", sandbox_path_str(path)])

        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise ExecNonZeroError(result, command=cmd)

    async def mv(
        self,
        source: Path | str,
        destination: Path | str,
        *,
        user: str | User | None = None,
    ) -> None:
        """Rename a regular file or symlink, replacing the destination entry if it exists.

        Directory and special-file sources are unsupported and rejected before the move.
        As with other workspace file APIs, callers must serialize conflicting mutations.

        The exec fallback requires ``mv -T`` (GNU or compatible). A tool without that option
        fails without moving the source. Do not replace it with a destination precheck: a
        concurrently created directory could otherwise receive the source as a child.

        This is the shell fallback for backends that only offer `exec`. A backend with
        direct filesystem access, such as UnixLocal, overrides it with a descriptor-relative
        `os.rename`, so the path it validated is the entry it renames.

        :param source: Regular file or symlink to move.
        :param destination: Path to move it to.
        :param user: Optional sandbox user to move as.
        :raises ExecNonZeroError: If the destination is an existing directory, or the move
                fails.
        """
        source = await self._validate_path_access(source, for_write=True)
        destination = await self._validate_path_access(destination, for_write=True)
        source_arg = sandbox_path_str(source)
        destination_arg = sandbox_path_str(destination)
        script = (
            'if [ ! -L "$1" ] && [ ! -f "$1" ]; then '
            'printf "%s\\n" "Move source must be a regular file or symlink" >&2; exit 1; fi; '
            'exec mv -fT -- "$1" "$2"'
        )
        cmd = ("sh", "-c", script, "sh", source_arg, destination_arg)
        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise ExecNonZeroError(
                result, command=("sh", "-c", "<mv>", source_arg, destination_arg)
            )

    async def same_file(
        self,
        left: Path | str,
        right: Path | str,
        *,
        follow_symlinks: bool = True,
        user: str | User | None = None,
    ) -> bool:
        """Return whether two paths name the same file on the sandbox filesystem.

        This asks the filesystem, through `test -ef`, which compares device and inode. Two
        paths that differ as strings can be one file: a filesystem that folds case stores
        `notes.txt` and `Notes.txt` as a single entry, and APFS folds Unicode normalization
        as well, so the NFC and NFD spellings of one accented name are also a single entry.
        No string comparison can answer this, and neither can the host that is driving the
        session, which may not be the kind of system the sandbox is running on.

        `test -ef` resolves symlinks. With ``follow_symlinks=False``, return false if either
        leaf is a symlink, including two paths naming the same symlink. This mode compares
        only non-symlink entries and is used before removing an apply-patch source.

        This is the shell fallback for backends that only offer `exec`. UnixLocal overrides
        it with a descriptor-relative `stat` on both entries.

        :param left: First path to compare.
        :param right: Second path to compare.
        :param follow_symlinks: If false, return false when either leaf is a symlink.
        :param user: Optional sandbox user to compare as.
        :returns: True when both paths resolve to the same file.
        """
        left = await self._validate_path_access(left)
        right = await self._validate_path_access(right)

        left_arg = sandbox_path_str(left)
        right_arg = sandbox_path_str(right)
        test = '[ "$1" -ef "$2" ]'
        if not follow_symlinks:
            test = '[ ! -L "$1" ] && [ ! -L "$2" ] && ' + test
        cmd = ("sh", "-lc", test, "sh", left_arg, right_arg)
        result = await self.exec(*cmd, shell=False, user=user)
        if result.exit_code == 0:
            return True
        # `[` answers "different file" with 1 and reports its own failures with 2, and a
        # missing shell exits 127. Only 1 is an answer; anything else is the session
        # failing to tell us, and a caller about to delete a file on the strength of this
        # must not read that as "different".
        if result.exit_code == 1:
            return False
        raise ExecNonZeroError(
            result, command=("sh", "-lc", "<same_file_check>", left_arg, right_arg)
        )

    async def mkdir(
        self,
        path: Path | str,
        *,
        parents: bool = False,
        user: str | User | None = None,
    ) -> None:
        """Create a directory.

        :param path: Directory to create on the remote.
        :param parents: If true, create missing parents.
        :param user: Optional sandbox user to create the directory as.
        """
        path = await self._validate_path_access(path, for_write=True)

        cmd: list[str] = ["mkdir"]
        if parents:
            cmd.append("-p")
        cmd.append(sandbox_path_str(path))

        result = await self.exec(*cmd, shell=False, user=user)
        if not result.ok():
            raise ExecNonZeroError(result, command=cmd)

    async def extract(
        self,
        path: Path | str,
        data: io.IOBase,
        *,
        compression_scheme: Literal["tar", "zip"] | None = None,
        archive_limits: SandboxArchiveLimits | None = None,
    ) -> None:
        """
        Write a compressed archive to a destination on the remote.
        Optionally extract the archive once written.

        :param path: Path on the host machine to extract to
        :param data: a file-like io stream.
        :param compression_scheme: either "tar" or "zip". If not provided,
            it will try to infer from the path.
        :param archive_limits: optional per-call archive resource limits. If omitted,
            the session default is used.
        """
        if archive_limits is not None:
            archive_limits.validate()
        effective_archive_limits = (
            archive_limits if archive_limits is not None else self._archive_limits
        )

        await archive_ops.extract_archive(
            self,
            path,
            data,
            compression_scheme=compression_scheme,
            archive_limits=effective_archive_limits,
        )

    async def apply_patch(
        self,
        operations: ApplyPatchOperation
        | dict[str, object]
        | list[ApplyPatchOperation | dict[str, object]],
        *,
        patch_format: PatchFormat | Literal["v4a"] = "v4a",
    ) -> str:
        return await WorkspaceEditor(self).apply_patch(operations, patch_format=patch_format)

    def normalize_path(self, path: Path | str, *, for_write: bool = False) -> Path:
        policy = self._workspace_path_policy()
        return policy.normalize_path(path, for_write=for_write)

    def describe(self) -> str:
        return self.state.manifest.describe()

    async def _extract_tar_archive(
        self,
        *,
        archive_path: Path,
        destination_root: Path,
        data: io.IOBase,
        archive_limits: SandboxArchiveLimits | None = None,
    ) -> None:
        await archive_ops.extract_tar_archive(
            self,
            archive_path=archive_path,
            destination_root=destination_root,
            data=data,
            archive_limits=archive_limits,
        )

    async def _extract_zip_archive(
        self,
        *,
        archive_path: Path,
        destination_root: Path,
        data: io.IOBase,
        archive_limits: SandboxArchiveLimits | None = None,
    ) -> None:
        await archive_ops.extract_zip_archive(
            self,
            archive_path=archive_path,
            destination_root=destination_root,
            data=data,
            archive_limits=archive_limits,
        )

    @staticmethod
    def _safe_zip_member_rel_path(member) -> Path | None:
        return archive_ops.safe_zip_member_rel_path(member)

    async def _apply_manifest(
        self,
        *,
        only_ephemeral: bool = False,
        provision_accounts: bool = True,
    ) -> MaterializationResult:
        return await manifest_ops.apply_manifest(
            self,
            only_ephemeral=only_ephemeral,
            provision_accounts=provision_accounts,
        )

    async def _validate_manifest_application(
        self,
        *,
        only_ephemeral: bool = False,
        manifest: Manifest | None = None,
        session_running: bool | None = None,
    ) -> None:
        _ = (only_ephemeral, session_running)
        from .._mount_security import validate_manifest_mount_credential_boundaries

        validate_manifest_mount_credential_boundaries(
            manifest or self.state.manifest,
            provider_backend_id=self.state.type,
        )

    @redact_mount_error_data
    async def apply_manifest(self, *, only_ephemeral: bool = False) -> MaterializationResult:
        await self._validate_manifest_application(only_ephemeral=only_ephemeral)
        return await self._apply_manifest(
            only_ephemeral=only_ephemeral,
            provision_accounts=not only_ephemeral,
        )

    async def provision_manifest_accounts(self) -> None:
        await manifest_ops.provision_manifest_accounts(self)

    def should_provision_manifest_accounts_on_resume(self) -> bool:
        """Return whether resume should reprovision manifest-managed users and groups."""

        return not self._system_state_preserved_on_start()

    async def _reapply_ephemeral_manifest_on_resume(self) -> None:
        """Rebuild ephemeral manifest state without touching persisted workspace files."""

        await self.apply_manifest(only_ephemeral=True)

    async def _restore_snapshot_into_workspace_on_resume(self) -> None:
        """Clear the live workspace contents and repopulate them from the persisted snapshot."""

        await snapshot_lifecycle.restore_snapshot_into_workspace_on_resume(self)

    async def _live_workspace_matches_snapshot_on_resume(self) -> bool:
        """Return whether the running sandbox workspace definitely matches the stored snapshot."""

        return await snapshot_lifecycle.live_workspace_matches_snapshot_on_resume(self)

    async def _can_skip_snapshot_restore_on_resume(self, *, is_running: bool) -> bool:
        """Return whether resume can safely reuse the running workspace without restore."""

        return await snapshot_lifecycle.can_skip_snapshot_restore_on_resume(
            self,
            is_running=is_running,
        )

    def _snapshot_fingerprint_cache_path(self) -> Path:
        """Return the runtime-owned path for this session's cached snapshot fingerprint."""

        return snapshot_lifecycle.snapshot_fingerprint_cache_path(self)

    def _workspace_fingerprint_skip_relpaths(self) -> set[Path]:
        """Return workspace paths that should be omitted from snapshot fingerprinting."""

        return snapshot_lifecycle.workspace_fingerprint_skip_relpaths(self)

    def _should_compute_snapshot_fingerprint_on_persist(self) -> bool:
        """Return whether persistence should fingerprint the workspace before archiving it."""

        return True

    async def _compute_and_cache_snapshot_fingerprint(
        self, *, version: str | None = None
    ) -> dict[str, str]:
        """Compute the current workspace fingerprint in-container and atomically cache it."""

        return await snapshot_lifecycle.compute_and_cache_snapshot_fingerprint(
            self, version=version
        )

    async def _read_cached_snapshot_fingerprint(self) -> dict[str, str]:
        """Read the cached snapshot fingerprint record from the running sandbox."""

        return await snapshot_lifecycle.read_cached_snapshot_fingerprint(self)

    def _parse_snapshot_fingerprint_record(
        self, payload: bytes | bytearray | str
    ) -> dict[str, str]:
        """Validate and normalize a cached snapshot fingerprint JSON payload."""

        return snapshot_lifecycle.parse_snapshot_fingerprint_record(payload)

    async def _delete_cached_snapshot_fingerprint_best_effort(self) -> None:
        """Remove the cached snapshot fingerprint file without raising on cleanup failure."""

        await snapshot_lifecycle.delete_cached_snapshot_fingerprint_best_effort(self)

    def _snapshot_fingerprint_version(self) -> str:
        """Return the version tag for the current snapshot fingerprint algorithm."""

        return snapshot_lifecycle.snapshot_fingerprint_version()

    def _resume_manifest_digest(self) -> str:
        """Return a stable digest of the manifest state that affects resume correctness."""

        return snapshot_lifecycle.resume_manifest_digest(self)

    async def _apply_entry_batch(
        self,
        entries: Sequence[tuple[Path, BaseEntry]],
        *,
        base_dir: Path,
    ) -> list[MaterializedFile]:
        return await manifest_ops.apply_entry_batch(self, entries, base_dir=base_dir)

    def _manifest_base_dir(self) -> Path:
        return Path.cwd()

    async def _exec_checked_nonzero(self, *command: str | Path) -> ExecResult:
        result = await self.exec(*command, shell=False)
        if not result.ok():
            raise ExecNonZeroError(result, command=command)
        return result

    async def _clear_workspace_root_on_resume(self) -> None:
        """
        Best-effort cleanup step for snapshot resume.

        We intentionally clear *contents* of the workspace root rather than deleting the root
        directory itself. Some sandboxes configure their process working directory to the workspace
        root (e.g. Modal sandboxes), and deleting the directory can make subsequent exec() calls
        fail with "failed to find initial working directory".
        """

        await snapshot_lifecycle.clear_workspace_root_on_resume(self)

    async def _remove_workspace_entry_on_resume(self, path: Path) -> None:
        """Remove a stale workspace entry before restoring a snapshot."""
        await self.rm(path, recursive=True)

    def _workspace_resume_mount_skip_relpaths(self) -> set[Path]:
        return snapshot_lifecycle.workspace_resume_mount_skip_relpaths(self)

    async def _clear_workspace_dir_on_resume_pruned(
        self,
        *,
        current_dir: Path,
        skip_rel_paths: set[Path],
    ) -> None:
        await snapshot_lifecycle.clear_workspace_dir_on_resume_pruned(
            self,
            current_dir=current_dir,
            skip_rel_paths=skip_rel_paths,
        )
