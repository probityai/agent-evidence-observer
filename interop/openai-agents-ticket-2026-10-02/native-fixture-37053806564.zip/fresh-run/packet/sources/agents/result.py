from __future__ import annotations

import abc
import asyncio
import copy
import weakref
from collections.abc import AsyncIterator
from dataclasses import InitVar, dataclass, field, replace
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from pydantic import GetCoreSchemaHandler
from pydantic_core import core_schema

from .agent import Agent
from .agent_output import AgentOutputSchemaBase
from .exceptions import (
    AgentsException,
    InputGuardrailTripwireTriggered,
    MaxTurnsExceeded,
    RunErrorDetails,
    _await_data_redacted_error_boundary,
    _detach_data_redacted_error_traceback,
    _is_error_data_redacted,
    _should_drain_stream_events_before_raising,
)
from .guardrail import InputGuardrailResult, OutputGuardrailResult
from .items import (
    ItemHelpers,
    ModelResponse,
    RunItem,
    ToolApprovalItem,
    TResponseInputItem,
)
from .logger import log_tool_action_warning, logger
from .run_context import RunContextWrapper
from .run_internal.items import (
    NestedHistoryOwnedItemRef,
    digest_input_item,
    filter_nested_history_owned_item_refs_for_input,
    rebase_nested_history_owned_item_refs,
    resolve_nested_history_owned_item_indexes,
    run_items_to_input_items,
)
from .run_internal.run_steps import (
    NextStepInterruption,
    ProcessedResponse,
    QueueCompleteSentinel,
)
from .run_state import RunState
from .stream_events import StreamEvent
from .tool_guardrails import ToolInputGuardrailResult, ToolOutputGuardrailResult
from .tracing import Trace
from .tracing.traces import TraceState
from .util._pretty_print import (
    pretty_print_result,
    pretty_print_run_result_streaming,
)

if TYPE_CHECKING:
    from collections.abc import Awaitable, Callable

    from .sandbox.session.base_sandbox_session import BaseSandboxSession

T = TypeVar("T")


@dataclass(frozen=True)
class AgentToolInvocation:
    """Immutable metadata about a nested agent-tool invocation."""

    tool_name: str
    """The nested tool name exposed to the model."""

    tool_call_id: str
    """The tool call ID for the nested invocation."""

    tool_arguments: str
    """The raw JSON arguments for the nested invocation."""


def _reconciled_result_owned_item_refs(
    result: RunResultBase,
    public_input: str | list[TResponseInputItem],
) -> list[NestedHistoryOwnedItemRef]:
    """Retain ownership only for the exact public-input occurrences."""
    owned_item_refs = getattr(result, "_nested_history_owned_session_item_refs", [])
    return filter_nested_history_owned_item_refs_for_input(
        public_input,
        owned_item_refs,
    )


def _state_snapshot_owned_item_refs(
    result: RunResultBase,
    state_input: str | list[TResponseInputItem],
) -> list[NestedHistoryOwnedItemRef]:
    """Rebind validated ownership coordinates to the input snapshot stored in RunState."""
    if isinstance(state_input, str):
        return []
    return [
        replace(item_ref, input_item=state_input[item_ref.input_index])
        for item_ref in getattr(result, "_nested_history_owned_session_item_refs", [])
        if 0 <= item_ref.input_index < len(state_input)
        and digest_input_item(state_input[item_ref.input_index]) == item_ref.digest
    ]


def _populate_state_from_result(
    state: RunState[Any],
    result: RunResultBase,
    *,
    current_turn: int,
    last_processed_response: ProcessedResponse | None,
    current_turn_persisted_item_count: int,
    tool_use_tracker_snapshot: dict[str, list[str]],
    conversation_id: str | None = None,
    previous_response_id: str | None = None,
    auto_previous_response_id: bool = False,
) -> RunState[Any]:
    """Populate a RunState with common fields from a RunResult."""
    state._current_agent = result.last_agent
    model_input_items = getattr(result, "_model_input_items", None)
    if isinstance(model_input_items, list):
        state._generated_items = list(model_input_items)
    else:
        state._generated_items = result.new_items
    state._session_items = list(result.new_items)
    snapshot_refs = _state_snapshot_owned_item_refs(result, state._original_input)
    live_refs = rebase_nested_history_owned_item_refs(
        state._original_input,
        state._session_items,
        snapshot_refs,
    )
    state._nested_history_owned_session_item_refs = live_refs
    state._model_responses = list(result.raw_responses)
    state._input_guardrail_results = result.input_guardrail_results
    state._output_guardrail_results = result.output_guardrail_results
    state._tool_input_guardrail_results = result.tool_input_guardrail_results
    state._tool_output_guardrail_results = result.tool_output_guardrail_results
    state._last_processed_response = last_processed_response
    state._current_turn = current_turn
    state._current_turn_persisted_item_count = current_turn_persisted_item_count
    state.set_tool_use_tracker_snapshot(tool_use_tracker_snapshot)
    state._conversation_id = conversation_id
    state._previous_response_id = previous_response_id
    state._auto_previous_response_id = auto_previous_response_id
    source_state = getattr(result, "_state", None)
    if isinstance(source_state, RunState):
        state._generated_prompt_cache_key = source_state._generated_prompt_cache_key
        state._pending_input = copy.deepcopy(source_state._pending_input)
        state._pending_session_write = copy.deepcopy(source_state._pending_session_write)
        state._current_step = source_state._current_step
        # A streamed result exists before its terminal append does, so a checkpoint taken from a
        # failed stream has to keep the fail-closed marker or it would look resumable.
        state._terminal_unrecoverable = source_state._terminal_unrecoverable
    else:
        state._generated_prompt_cache_key = getattr(result, "_generated_prompt_cache_key", None)
        state._pending_input = copy.deepcopy(getattr(result, "_pending_input_for_state", []))
        state._current_step = getattr(result, "_current_step_for_state", None)
    state._reasoning_item_id_policy = getattr(result, "_reasoning_item_id_policy", None)

    interruptions = list(getattr(result, "interruptions", []))
    if interruptions:
        state._current_step = NextStepInterruption(interruptions=interruptions)

    trace_state = getattr(result, "_trace_state", None)
    if trace_state is None:
        trace_state = TraceState.from_trace(getattr(result, "trace", None))
    state._trace_state = copy.deepcopy(trace_state) if trace_state is not None else None
    sandbox_resume_state = getattr(result, "_sandbox_resume_state", None)
    if isinstance(sandbox_resume_state, dict):
        state._sandbox = copy.deepcopy(sandbox_resume_state)
    else:
        state._sandbox = None

    return state


def _copy_pending_nested_agent_tool_states(state: RunState[Any], result: RunResultBase) -> None:
    """Bind detached nested approval checkpoints to the new outer checkpoint scope."""
    if state._last_processed_response is None:
        return

    from .agent_tool_state import (
        drop_agent_tool_run_result,
        get_agent_tool_resume_state,
        get_agent_tool_state_scope,
        peek_agent_tool_run_result,
        record_agent_tool_resume_state,
    )

    source_scope = get_agent_tool_state_scope(result.context_wrapper)
    templates = getattr(result, "_checkpoint_nested_state_templates", None)
    if not isinstance(templates, dict):
        templates = {}
        result.__dict__["_checkpoint_nested_state_templates"] = templates
    for function_run in state._last_processed_response.functions:
        template = templates.get(id(function_run.tool_call))
        if isinstance(template, RunState):
            nested_state = template._copy_for_result_checkpoint()
            resolved_interruptions = template.get_interruptions()
        else:
            pending_result = peek_agent_tool_run_result(
                function_run.tool_call,
                scope_id=source_scope,
            )
            pending_interruptions = getattr(pending_result, "interruptions", None)
            to_state = getattr(pending_result, "to_state", None)
            if (
                not isinstance(pending_interruptions, list)
                or not pending_interruptions
                or not callable(to_state)
            ):
                continue
            pending_state = get_agent_tool_resume_state(pending_result)
            copy_for_checkpoint = getattr(pending_state, "_copy_for_result_checkpoint", None)
            template = copy_for_checkpoint() if callable(copy_for_checkpoint) else to_state()
            if not isinstance(template, RunState):
                continue
            templates[id(function_run.tool_call)] = template
            drop_agent_tool_run_result(function_run.tool_call, scope_id=source_scope)
            nested_state = template._copy_for_result_checkpoint()
            resolved_interruptions = pending_interruptions
        if not isinstance(nested_state, RunState) or nested_state is state:
            continue
        record_agent_tool_resume_state(
            function_run.tool_call,
            nested_state,
            scope_id=state._agent_tool_state_scope_id,
            approval_items=resolved_interruptions,
        )


ToInputListMode = Literal["preserve_all", "normalized"]


def _preserve_all_session_items(
    result: RunResultBase,
    reasoning_item_id_policy: Literal["preserve", "omit"] | None,
    public_input: str | list[TResponseInputItem],
    owned_item_refs: list[NestedHistoryOwnedItemRef],
) -> list[TResponseInputItem]:
    """Avoid replaying session items already moved into ordered nested history."""
    retained_refs = filter_nested_history_owned_item_refs_for_input(
        public_input,
        owned_item_refs,
    )
    excluded = resolve_nested_history_owned_item_indexes(
        result.new_items,
        retained_refs,
    )
    if not excluded:
        return run_items_to_input_items(result.new_items, reasoning_item_id_policy)

    filtered_items = [item for index, item in enumerate(result.new_items) if index not in excluded]
    return run_items_to_input_items(filtered_items, reasoning_item_id_policy)


def _input_items_for_result(
    result: RunResultBase,
    *,
    mode: ToInputListMode,
    reasoning_item_id_policy: Literal["preserve", "omit"] | None,
    public_input: str | list[TResponseInputItem],
    owned_item_refs: list[NestedHistoryOwnedItemRef],
) -> list[TResponseInputItem]:
    """Return input items for the requested result view.

    ``preserve_all`` keeps the full converted history from ``new_items``. ``normalized`` returns
    the canonical continuation input when handoff filtering rewrote model history, otherwise it
    falls back to the same converted history.
    """
    if mode == "preserve_all":
        return _preserve_all_session_items(
            result,
            reasoning_item_id_policy,
            public_input,
            owned_item_refs,
        )
    if mode != "normalized":
        raise ValueError(f"Unsupported to_input_list mode: {mode}")
    session_items = run_items_to_input_items(result.new_items, reasoning_item_id_policy)
    if not getattr(result, "_replay_from_model_input_items", False):
        # Most runs never rewrite continuation history, so normalized stays identical to the
        # historical preserve-all view unless the runner explicitly marked a divergence.
        return session_items

    model_input_items = getattr(result, "_model_input_items", None)
    if not isinstance(model_input_items, list):
        return session_items

    # When the runner marks a divergence, generated_items already reflect the continuation input
    # chosen for the next local run after applying handoff/input filtering.
    return run_items_to_input_items(model_input_items, reasoning_item_id_policy)


def _starting_agent_for_state(result: RunResultBase) -> Agent[Any]:
    """Return the root agent graph that should seed RunState identity resolution."""
    state = getattr(result, "_state", None)
    starting_agent = getattr(state, "_starting_agent", None)
    if isinstance(starting_agent, Agent):
        return starting_agent

    stored_starting_agent = getattr(result, "_starting_agent_for_state", None)
    if isinstance(stored_starting_agent, Agent):
        return stored_starting_agent

    return result.last_agent


@dataclass
class RunResultBase(abc.ABC):
    input: str | list[TResponseInputItem]
    """The original input items i.e. the items before run() was called. This may be a mutated
    version of the input, if there are handoff input filters that mutate the input.
    """

    new_items: list[RunItem]
    """The new items generated during the agent run. These include things like new messages, tool
    calls and their outputs, etc.
    """

    raw_responses: list[ModelResponse]
    """The raw LLM responses generated by the model during the agent run."""

    final_output: Any
    """The output of the last agent."""

    input_guardrail_results: list[InputGuardrailResult]
    """Guardrail results for the input messages."""

    output_guardrail_results: list[OutputGuardrailResult]
    """Guardrail results for the final output of the agent."""

    tool_input_guardrail_results: list[ToolInputGuardrailResult]
    """Tool input guardrail results from all tools executed during the run."""

    tool_output_guardrail_results: list[ToolOutputGuardrailResult]
    """Tool output guardrail results from all tools executed during the run."""

    context_wrapper: RunContextWrapper[Any]
    """The context wrapper for the agent run."""

    _trace_state: TraceState | None = field(default=None, init=False, repr=False)
    """Serialized trace metadata captured during the run."""
    _replay_from_model_input_items: bool = field(default=False, init=False, repr=False)
    """Whether replay helpers should prefer `_model_input_items` over `new_items`.

    This is only set when the runner preserved extra session history items that should not be
    replayed into the next local run, such as nested handoff history or filtered handoff input.
    """
    _nested_history_owned_session_item_refs: list[NestedHistoryOwnedItemRef] = field(
        default_factory=list,
        init=False,
        repr=False,
    )
    """Session item occurrences already represented verbatim in SDK-default nested history."""
    _sandbox_resume_state: dict[str, object] | None = field(default=None, init=False, repr=False)
    """Serialized sandbox session state captured during the run."""
    _sandbox_session: BaseSandboxSession | None = field(default=None, init=False, repr=False)
    """Live sandbox session attached to this run result when sandbox execution is enabled."""
    _starting_agent_for_state: Agent[Any] | None = field(default=None, init=False, repr=False)
    """Root agent graph used when converting the result back into RunState."""
    _generated_prompt_cache_key: str | None = field(default=None, init=False, repr=False)
    """SDK-generated prompt cache key captured during the run."""
    _pending_input_for_state: list[TResponseInputItem] = field(
        default_factory=list, init=False, repr=False
    )
    """Pending input preserved when a non-streaming result is converted back to RunState."""
    _current_step_for_state: Any = field(default=None, init=False, repr=False)
    """Current step preserved when a non-streaming result is converted back to RunState."""

    @classmethod
    def __get_pydantic_core_schema__(
        cls,
        _source_type: Any,
        _handler: GetCoreSchemaHandler,
    ) -> core_schema.CoreSchema:
        # RunResult objects are runtime values; schema generation should treat them as instances
        # instead of recursively traversing internal dataclass annotations.
        return core_schema.is_instance_schema(cls)

    @property
    @abc.abstractmethod
    def last_agent(self) -> Agent[Any]:
        """The last agent that was run."""

    def release_agents(self, *, release_new_items: bool = True) -> None:
        """
        Release strong references to agents held by this result. After calling this method,
        accessing `item.agent` or `last_agent` may return `None` if the agent has been garbage
        collected. Callers can use this when they are done inspecting the result and want to
        eagerly drop any associated agent graph.
        """
        if release_new_items:
            for item in self.new_items:
                release = getattr(item, "release_agent", None)
                if callable(release):
                    release()
        self._release_last_agent_reference()

    def __del__(self) -> None:
        try:
            # Fall back to releasing agents automatically in case the caller never invoked
            # `release_agents()` explicitly so GC of the RunResult drops the last strong reference.
            # We pass `release_new_items=False` so RunItems that the user intentionally keeps
            # continue exposing their originating agent until that agent itself is collected.
            self.release_agents(release_new_items=False)
        except Exception:
            # Avoid raising from __del__.
            pass

    @abc.abstractmethod
    def _release_last_agent_reference(self) -> None:
        """Release stored agent reference specific to the concrete result type."""

    def final_output_as(self, cls: type[T], raise_if_incorrect_type: bool = False) -> T:
        """A convenience method to cast the final output to a specific type. By default, the cast
        is only for the typechecker. If you set `raise_if_incorrect_type` to True, we'll raise a
        TypeError if the final output is not of the given type.

        Args:
            cls: The type to cast the final output to.
            raise_if_incorrect_type: If True, we'll raise a TypeError if the final output is not of
                the given type.

        Returns:
            The final output casted to the given type.
        """
        if raise_if_incorrect_type and not isinstance(self.final_output, cls):
            raise TypeError(f"Final output is not of type {cls.__name__}")

        return cast(T, self.final_output)

    def to_input_list(
        self,
        *,
        mode: ToInputListMode = "preserve_all",
    ) -> list[TResponseInputItem]:
        """Create an input-item view of this run.

        ``mode="preserve_all"`` keeps the historical behavior of converting ``new_items`` into a
        full plain-item history. ``mode="normalized"`` prefers the canonical continuation input
        when handoff filtering rewrote model history, while remaining identical for ordinary runs.
        """
        public_input = self.input
        owned_item_refs = _reconciled_result_owned_item_refs(self, public_input)
        original_items = ItemHelpers.input_to_new_input_list(public_input)
        reasoning_item_id_policy = getattr(self, "_reasoning_item_id_policy", None)
        replay_items = _input_items_for_result(
            self,
            mode=mode,
            reasoning_item_id_policy=reasoning_item_id_policy,
            public_input=public_input,
            owned_item_refs=owned_item_refs,
        )
        return original_items + replay_items

    @property
    def agent_tool_invocation(self) -> AgentToolInvocation | None:
        """Immutable metadata for results produced by `Agent.as_tool()`.

        Returns `None` for ordinary top-level runs.
        """
        from .tool_context import ToolContext

        if not isinstance(self.context_wrapper, ToolContext):
            return None

        return AgentToolInvocation(
            tool_name=self.context_wrapper.tool_name,
            tool_call_id=self.context_wrapper.tool_call_id,
            tool_arguments=self.context_wrapper.tool_arguments,
        )

    @property
    def last_response_id(self) -> str | None:
        """Convenience method to get the response ID of the last model response."""
        if not self.raw_responses:
            return None

        return self.raw_responses[-1].response_id


@dataclass
class RunResult(RunResultBase):
    _last_agent: Agent[Any]
    _last_agent_ref: weakref.ReferenceType[Agent[Any]] | None = field(
        init=False,
        repr=False,
        default=None,
    )
    _last_processed_response: ProcessedResponse | None = field(default=None, repr=False)
    """The last processed model response. This is needed for resuming from interruptions."""
    _tool_use_tracker_snapshot: dict[str, list[str]] = field(default_factory=dict, repr=False)
    _current_turn_persisted_item_count: int = 0
    """Number of items from new_items already persisted to session for the
    current turn."""
    _current_turn: int = 0
    """The current turn number. This is preserved when converting to RunState."""
    _model_input_items: list[RunItem] = field(default_factory=list, repr=False)
    """Filtered items used to build model input when resuming runs."""
    _original_input: str | list[TResponseInputItem] | None = field(default=None, repr=False)
    """The original input for the current run segment.
    This is updated when handoffs or resume logic replace the input history, and used by to_state()
    to preserve the correct originalInput when serializing state."""
    _conversation_id: str | None = field(default=None, repr=False)
    """Conversation identifier for server-managed runs."""
    _previous_response_id: str | None = field(default=None, repr=False)
    """Response identifier returned by the server for the last turn."""
    _auto_previous_response_id: bool = field(default=False, repr=False)
    """Whether automatic previous response tracking was enabled."""
    _reasoning_item_id_policy: Literal["preserve", "omit"] | None = field(
        default=None, init=False, repr=False
    )
    """How reasoning IDs should be represented when converting to input history."""
    max_turns: int | None = 10
    """The maximum number of turns allowed for this run, or ``None`` for no limit."""
    interruptions: list[ToolApprovalItem] = field(default_factory=list)
    """Pending tool approval requests (interruptions) for this run."""

    def __post_init__(self) -> None:
        self._last_agent_ref = weakref.ref(self._last_agent)

    @property
    def last_agent(self) -> Agent[Any]:
        """The last agent that was run."""
        agent = cast("Agent[Any] | None", self.__dict__.get("_last_agent"))
        if agent is not None:
            return agent
        if self._last_agent_ref:
            agent = self._last_agent_ref()
            if agent is not None:
                return agent
        raise AgentsException("Last agent reference is no longer available.")

    def _release_last_agent_reference(self) -> None:
        agent = cast("Agent[Any] | None", self.__dict__.get("_last_agent"))
        if agent is None:
            return
        self._last_agent_ref = weakref.ref(agent)
        # Preserve dataclass field so repr/asdict continue to succeed.
        self.__dict__["_last_agent"] = None

    def to_state(self) -> RunState[Any]:
        """Create a RunState from this result to resume execution.

        This is useful when the run was interrupted (e.g., for tool approval). You can
        approve or reject the tool calls on the returned state, then pass it back to
        `Runner.run()` to continue execution.

        Returns:
            A RunState that can be used to resume the run.

        Example:
            ```python
            # Run agent until it needs approval
            result = await Runner.run(agent, "Use the delete_file tool")

            if result.interruptions:
                # Approve the tool call
                state = result.to_state()
                state.approve(result.interruptions[0])

                # Resume the run
                result = await Runner.run(agent, state)
            ```
        """
        # Create a RunState from the current result
        original_input_for_state = getattr(self, "_original_input", None)
        state = RunState(
            context=self.context_wrapper._copy_for_run_state(),
            original_input=original_input_for_state
            if original_input_for_state is not None
            else self.input,
            starting_agent=_starting_agent_for_state(self),
            max_turns=self.max_turns,
        )

        state = _populate_state_from_result(
            state,
            self,
            current_turn=self._current_turn,
            last_processed_response=self._last_processed_response,
            current_turn_persisted_item_count=self._current_turn_persisted_item_count,
            tool_use_tracker_snapshot=self._tool_use_tracker_snapshot,
            conversation_id=self._conversation_id,
            previous_response_id=self._previous_response_id,
            auto_previous_response_id=self._auto_previous_response_id,
        )
        _copy_pending_nested_agent_tool_states(state, self)
        return state

    def __str__(self) -> str:
        return pretty_print_result(self)


@dataclass
class RunResultStreaming(RunResultBase):
    """The result of an agent run in streaming mode. You can use the `stream_events` method to
    receive semantic events as they are generated.

    The streaming method will raise:
    - A MaxTurnsExceeded exception if the agent exceeds the max_turns limit.
    - A tripwire exception if a guardrail is tripped, e.g. InputGuardrailTripwireTriggered
      or OutputGuardrailTripwireTriggered.
    """

    current_agent: Agent[Any]
    """The current agent that is running."""

    current_turn: int
    """The current turn number."""

    max_turns: int | None
    """The maximum number of turns the agent can run for, or ``None`` for no limit."""

    final_output: Any
    """The final output of the agent. This is None until the agent has finished running."""

    _current_agent_output_schema: AgentOutputSchemaBase | None = field(repr=False)

    trace: Trace | None = field(repr=False)

    is_complete: bool = False
    """Whether the agent has finished running."""

    _current_agent_ref: weakref.ReferenceType[Agent[Any]] | None = field(
        init=False,
        repr=False,
        default=None,
    )

    _model_input_items: list[RunItem] = field(default_factory=list, repr=False)
    """Filtered items used to build model input between streaming turns."""

    # Queues that the background run_loop writes to
    _event_queue: asyncio.Queue[StreamEvent | QueueCompleteSentinel] = field(
        default_factory=asyncio.Queue, repr=False
    )
    _input_guardrail_queue: asyncio.Queue[InputGuardrailResult] = field(
        default_factory=asyncio.Queue, repr=False
    )

    # Store the asyncio tasks that we're waiting on
    run_loop_task: asyncio.Task[Any] | None = field(default=None, repr=False)
    _input_guardrails_task: asyncio.Task[Any] | None = field(default=None, repr=False)
    _triggered_input_guardrail_result: InputGuardrailResult | None = field(default=None, repr=False)
    _output_guardrails_task: asyncio.Task[Any] | None = field(default=None, repr=False)
    _stored_exception: BaseException | None = field(default=None, repr=False)
    _cancel_mode: Literal["none", "immediate", "after_turn"] = field(default="none", repr=False)
    _last_processed_response: ProcessedResponse | None = field(default=None, repr=False)
    """The last processed model response. This is needed for resuming from interruptions."""
    interruptions: list[ToolApprovalItem] = field(default_factory=list)
    """Pending tool approval requests (interruptions) for this run."""
    _waiting_on_event_queue: bool = field(default=False, repr=False)
    _active_stream_consumers: int = field(default=0, init=False, repr=False)
    _stream_consumers_stopped: asyncio.Event = field(
        default_factory=asyncio.Event, init=False, repr=False
    )

    _current_turn_persisted_item_count: int = 0
    """Number of items from new_items already persisted to session for the
    current turn."""

    _stream_input_persisted: bool = False
    """Whether the input has been persisted to the session. Prevents double-saving."""

    _original_input_for_persistence: list[TResponseInputItem] | None = None
    """Original turn input before session history was merged, used for
    persistence (matches JS sessionInputOriginalSnapshot)."""

    _max_turns_handled: bool = field(default=False, repr=False)

    _original_input: str | list[TResponseInputItem] | None = field(default=None, repr=False)
    """The original input from the first turn. Unlike `input`, this is never updated during the run.
    Used by to_state() to preserve the correct originalInput when serializing state."""
    _tool_use_tracker_snapshot: dict[str, list[str]] = field(default_factory=dict, repr=False)
    _state: Any = field(default=None, repr=False)
    """Internal reference to the RunState for streaming results."""
    _conversation_id: str | None = field(default=None, repr=False)
    """Conversation identifier for server-managed runs."""
    _previous_response_id: str | None = field(default=None, repr=False)
    """Response identifier returned by the server for the last turn."""
    _auto_previous_response_id: bool = field(default=False, repr=False)
    """Whether automatic previous response tracking was enabled."""
    _reasoning_item_id_policy: Literal["preserve", "omit"] | None = field(
        default=None, init=False, repr=False
    )
    """How reasoning IDs should be represented when converting to input history."""
    _run_impl_task: InitVar[asyncio.Task[Any] | None] = None
    _sandbox_cleanup: Callable[[], Awaitable[None]] | None = field(
        default=None,
        init=False,
        repr=False,
    )
    _sandbox_cleanup_task: asyncio.Task[None] | None = field(default=None, init=False, repr=False)
    _sandbox_cleanup_callback_registered: bool = field(default=False, init=False, repr=False)
    _sandbox_wrapped_run_loop_task: asyncio.Task[Any] | None = field(
        default=None,
        init=False,
        repr=False,
    )
    _model_provider_cleanup: Callable[[], Awaitable[None]] | None = field(
        default=None,
        init=False,
        repr=False,
    )
    _model_provider_cleanup_task: asyncio.Task[None] | None = field(
        default=None,
        init=False,
        repr=False,
    )

    def __post_init__(self, _run_impl_task: asyncio.Task[Any] | None) -> None:
        self._current_agent_ref = weakref.ref(self.current_agent)
        # Store the original input at creation time (it will be set via input field)
        if self._original_input is None:
            self._original_input = self.input
        # Compatibility shim: accept legacy `_run_impl_task` constructor keyword.
        if self.run_loop_task is None and _run_impl_task is not None:
            self.run_loop_task = _run_impl_task

    @property
    def last_agent(self) -> Agent[Any]:
        """The last agent that was run. Updates as the agent run progresses, so the true last agent
        is only available after the agent run is complete.
        """
        agent = cast("Agent[Any] | None", self.__dict__.get("current_agent"))
        if agent is not None:
            return agent
        if self._current_agent_ref:
            agent = self._current_agent_ref()
            if agent is not None:
                return agent
        raise AgentsException("Last agent reference is no longer available.")

    def _release_last_agent_reference(self) -> None:
        agent = cast("Agent[Any] | None", self.__dict__.get("current_agent"))
        if agent is None:
            return
        self._current_agent_ref = weakref.ref(agent)
        # Preserve dataclass field so repr/asdict continue to succeed.
        self.__dict__["current_agent"] = None

    async def _run_sandbox_cleanup(self) -> None:
        sandbox_cleanup = self._sandbox_cleanup
        if sandbox_cleanup is None:
            return

        task = self._sandbox_cleanup_task
        if task is None:

            async def _cleanup_once() -> None:
                try:
                    await sandbox_cleanup()
                except Exception as error:
                    log_tool_action_warning(
                        logger,
                        "Failed to clean up sandbox resources after streamed run",
                        error,
                    )

            task = asyncio.create_task(_cleanup_once())
            self._sandbox_cleanup_task = task

        await task

    def ensure_sandbox_cleanup_on_completion(self) -> None:
        if (
            self._sandbox_cleanup is None
            or self.run_loop_task is None
            or self._sandbox_cleanup_callback_registered
        ):
            return

        original_task = self.run_loop_task
        self._sandbox_wrapped_run_loop_task = original_task
        self._sandbox_cleanup_callback_registered = True
        original_task.add_done_callback(
            lambda _task: asyncio.create_task(self._run_sandbox_cleanup())
        )

        async def _await_run_and_cleanup() -> Any:
            try:
                result = await original_task
            except asyncio.CancelledError as error:
                if not original_task.done():
                    original_task.cancel()
                if _is_error_data_redacted(error):
                    _detach_data_redacted_error_traceback(error)
                raise
            except Exception as error:
                await self._run_sandbox_cleanup()
                if _is_error_data_redacted(error):
                    _detach_data_redacted_error_traceback(error)
                raise
            except BaseException as error:
                if _is_error_data_redacted(error):
                    _detach_data_redacted_error_traceback(error)
                raise

            await self._run_sandbox_cleanup()
            return result

        cleanup_wrapper_task = asyncio.create_task(
            _await_data_redacted_error_boundary(_await_run_and_cleanup)
        )

        def cancel_original_if_wrapper_cancelled(task: asyncio.Task[Any]) -> None:
            # A task cancelled before its first event-loop step cannot enter its coroutine body.
            if task.cancelled() and not original_task.done():
                original_task.cancel()

        cleanup_wrapper_task.add_done_callback(cancel_original_if_wrapper_cancelled)
        self.run_loop_task = cleanup_wrapper_task

    def _ensure_model_provider_cleanup_on_completion(
        self,
        cleanup: Callable[[], Awaitable[None]],
    ) -> None:
        """Register one cleanup task that also starts if the run task never enters its body."""
        self._model_provider_cleanup = cleanup
        if self.run_loop_task is not None:
            self.run_loop_task.add_done_callback(lambda _task: self._start_model_provider_cleanup())

    def _start_model_provider_cleanup(self) -> asyncio.Task[None] | None:
        task = self._model_provider_cleanup_task
        if task is not None:
            return task

        cleanup = self._model_provider_cleanup
        if cleanup is None:
            return None

        self._model_provider_cleanup = None

        async def run_cleanup() -> None:
            await cleanup()

        task = asyncio.create_task(run_cleanup())
        self._model_provider_cleanup_task = task
        return task

    async def _await_model_provider_cleanup(self) -> None:
        task = self._start_model_provider_cleanup()
        if task is not None:
            await asyncio.shield(task)

    @property
    def run_loop_exception(self) -> BaseException | None:
        """The exception raised by the background run loop, if any.

        When the run loop fails before producing stream events (for example during early
        sandbox initialisation), the exception may not be re-raised through
        :meth:`stream_events`. This property gives callers a reliable way to check for
        silent failures after consuming the stream:

        .. code-block:: python

            result = Runner.run_streamed(agent, "hello")
            async for event in result.stream_events():
                pass
            if result.run_loop_exception:
                raise result.run_loop_exception

        Returns ``None`` if the run loop completed without error, has not yet finished,
        or was cancelled.
        """
        task = self.run_loop_task
        if task is None or not task.done() or task.cancelled():
            return None
        error = task.exception()
        if error is not None and _is_error_data_redacted(error):
            _detach_data_redacted_error_traceback(error)
        return error

    def cancel(self, mode: Literal["immediate", "after_turn"] = "immediate") -> None:
        """Cancel the streaming run.

        Args:
            mode: Cancellation strategy:
                - "immediate": Stop immediately, cancel all tasks, clear queues (default)
                - "after_turn": Complete current turn gracefully before stopping
                    * Allows LLM response to finish
                    * Executes pending tool calls
                    * Saves session state properly
                    * Tracks usage accurately
                    * Stops before next turn begins

        Example:
            ```python
            result = Runner.run_streamed(agent, "Task", session=session)

            async for event in result.stream_events():
                if user_interrupted():
                    result.cancel(mode="after_turn")  # Graceful
                    # result.cancel()  # Immediate (default)
            ```

        Note: After calling cancel(), you should continue consuming stream_events()
        to allow the cancellation to complete properly.
        """
        # Store the cancel mode for the background task to check
        self._cancel_mode = mode

        if mode == "immediate":
            # Existing behavior - immediate shutdown
            self._cleanup_tasks()  # Cancel all running tasks
            self.is_complete = True  # Mark the run as complete to stop event streaming

            while not self._input_guardrail_queue.empty():
                self._input_guardrail_queue.get_nowait()

            # Unblock any streamers waiting on the event queue.
            self._event_queue.put_nowait(QueueCompleteSentinel())
            if not self._waiting_on_event_queue:
                self._drain_event_queue()

        elif mode == "after_turn":
            # Soft cancel - just set the flag
            # The streaming loop will check this and stop gracefully
            # Don't call _cleanup_tasks() or clear queues yet
            pass

    async def _wait_for_turn_event_consumption(self) -> None:
        """Wait for active consumers to finish processing the current turn's events."""
        if self._active_stream_consumers == 0:
            return

        queue_drained = asyncio.create_task(self._event_queue.join())
        consumers_stopped = asyncio.create_task(self._stream_consumers_stopped.wait())
        tasks = {queue_drained, consumers_stopped}
        try:
            await asyncio.wait(tasks, return_when=asyncio.FIRST_COMPLETED)
        finally:
            for task in tasks:
                if not task.done():
                    task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    async def stream_events(self) -> AsyncIterator[StreamEvent]:
        """Stream deltas for new items as they are generated. We're using the types from the
        OpenAI Responses API, so these are semantic events: each event has a `type` field that
        describes the type of the event, along with the data for that event.

        This will raise:
        - A MaxTurnsExceeded exception if the agent exceeds the max_turns limit.
        - A tripwire exception if a guardrail is tripped, e.g. InputGuardrailTripwireTriggered
          or OutputGuardrailTripwireTriggered.
        """
        consumer_registered = False
        registered_consumer_task: asyncio.Task[Any] | None = None
        item_acknowledgement_pending = False

        def acknowledge_item() -> None:
            nonlocal item_acknowledgement_pending
            if not item_acknowledgement_pending:
                return
            item_acknowledgement_pending = False
            self._event_queue.task_done()

        def unregister_consumer() -> None:
            nonlocal consumer_registered, registered_consumer_task
            if not consumer_registered:
                return
            acknowledge_item()
            consumer_registered = False
            registered_consumer_task = None
            self._active_stream_consumers -= 1
            if self._active_stream_consumers == 0:
                self._stream_consumers_stopped.set()

        def consumer_task_done(task: asyncio.Task[Any]) -> None:
            if registered_consumer_task is not task:
                return
            if task.cancelled() or task.exception() is not None:
                unregister_consumer()

        def register_current_consumer() -> None:
            nonlocal consumer_registered, registered_consumer_task
            current_task = asyncio.current_task()
            if current_task is None or registered_consumer_task is current_task:
                return
            if registered_consumer_task is not None:
                registered_consumer_task.remove_done_callback(consumer_task_done)
            registered_consumer_task = current_task
            if not consumer_registered:
                consumer_registered = True
                self._active_stream_consumers += 1
                self._stream_consumers_stopped.clear()
            current_task.add_done_callback(consumer_task_done)

        register_current_consumer()
        cancelled = False
        try:
            while True:
                register_current_consumer()
                self._check_errors()
                should_drain_queued_events = isinstance(
                    self._stored_exception, MaxTurnsExceeded
                ) or (
                    self._stored_exception is not None
                    and _should_drain_stream_events_before_raising(self._stored_exception)
                )
                if self._stored_exception is not None and (
                    not should_drain_queued_events or self._event_queue.empty()
                ):
                    logger.debug("Breaking due to stored exception")
                    self.is_complete = True
                    break

                if self.is_complete and self._event_queue.empty():
                    break

                try:
                    self._waiting_on_event_queue = True
                    item = await self._event_queue.get()
                except asyncio.CancelledError:
                    cancelled = True
                    self.cancel()
                    raise
                finally:
                    self._waiting_on_event_queue = False

                if isinstance(item, QueueCompleteSentinel):
                    # Await input guardrails if they are still running, so late
                    # exceptions are captured.
                    await self._await_task_safely(self._input_guardrails_task)

                    self._event_queue.task_done()

                    # Check for errors, in case the queue was completed
                    # due to an exception
                    self._check_errors()
                    break

                item_acknowledgement_pending = True
                try:
                    yield item
                finally:
                    acknowledge_item()
        finally:
            if registered_consumer_task is not None:
                registered_consumer_task.remove_done_callback(consumer_task_done)
            unregister_consumer()
            try:
                try:
                    if cancelled:
                        # Queue-wait cancellation should return without awaiting long-running tasks.
                        # Tasks have already been cancelled above.
                        self._cleanup_tasks()
                    else:
                        # Ensure main execution completes before cleanup to avoid race conditions
                        # with session operations.
                        await self._await_task_safely(self.run_loop_task)
                        # Re-check for exceptions now that the run loop has fully settled.
                        # _await_task_safely leaves errors to _check_errors(); without this call,
                        # a run-loop failure racing past the sentinel would be silently lost.
                        self._check_errors()
                        # Safely terminate background tasks after main execution has finished.
                        self._cleanup_tasks()
                finally:
                    if not cancelled:
                        await self._await_model_provider_cleanup()
                        await self._run_sandbox_cleanup()
            finally:
                # Allow any pending callbacks (e.g., cancellation handlers) to enqueue their
                # completion sentinels before we clear the queues for observability.
                await asyncio.sleep(0)

                # Drain queues so callers observing internal state see them empty after completion.
                self._drain_event_queue()
                self._drain_input_guardrail_queue()

        stored_exception = self._stored_exception
        if stored_exception is not None:
            if _is_error_data_redacted(stored_exception):
                _detach_data_redacted_error_traceback(stored_exception)
                # The streaming result retains caller-visible run data. Drop the local reference
                # before raising so the redacted exception cannot retain it through this frame.
                self = cast(Any, None)
                registered_consumer_task = None
                item = cast(Any, None)
            raise stored_exception

    def _create_error_details(self) -> RunErrorDetails | None:
        """Return a `RunErrorDetails` object considering the current attributes of the class.
        Returns ``None`` when the current agent can no longer be resolved, preserving the
        original terminal exception.
        """
        try:
            last_agent = self.last_agent
        except AgentsException:
            return None
        return RunErrorDetails(
            input=self.input,
            new_items=self.new_items,
            raw_responses=self.raw_responses,
            last_agent=last_agent,
            context_wrapper=self.context_wrapper,
            input_guardrail_results=self.input_guardrail_results,
            output_guardrail_results=self.output_guardrail_results,
            tool_input_guardrail_results=self.tool_input_guardrail_results,
            tool_output_guardrail_results=self.tool_output_guardrail_results,
        )

    def _check_errors(self):
        if (
            self.max_turns is not None
            and self.current_turn > self.max_turns
            and not self._max_turns_handled
        ):
            max_turns_exc = MaxTurnsExceeded(f"Max turns ({self.max_turns}) exceeded")
            max_turns_exc.run_data = self._create_error_details()
            self._stored_exception = max_turns_exc
            self._max_turns_handled = True

        # Fetch all the completed guardrail results from the queue and raise if needed
        while not self._input_guardrail_queue.empty():
            guardrail_result = self._input_guardrail_queue.get_nowait()
            if guardrail_result.output.tripwire_triggered:
                tripwire_exc = InputGuardrailTripwireTriggered(guardrail_result)
                tripwire_exc.run_data = self._create_error_details()
                self._stored_exception = tripwire_exc

        # Check the tasks for any exceptions
        if self.run_loop_task and self.run_loop_task.done():
            if not self.run_loop_task.cancelled():
                run_impl_exc = self.run_loop_task.exception()
                if run_impl_exc is not None:
                    if (
                        isinstance(run_impl_exc, AgentsException)
                        and run_impl_exc.run_data is None
                        and not _is_error_data_redacted(run_impl_exc)
                    ):
                        run_impl_exc.run_data = self._create_error_details()
                    self._stored_exception = run_impl_exc

        if self._input_guardrails_task and self._input_guardrails_task.done():
            if not self._input_guardrails_task.cancelled():
                in_guard_exc = self._input_guardrails_task.exception()
                if isinstance(in_guard_exc, Exception):
                    if (
                        isinstance(in_guard_exc, AgentsException)
                        and in_guard_exc.run_data is None
                        and not _is_error_data_redacted(in_guard_exc)
                    ):
                        in_guard_exc.run_data = self._create_error_details()
                    self._stored_exception = in_guard_exc

    def _cleanup_tasks(self):
        if self.run_loop_task and not self.run_loop_task.done():
            self.run_loop_task.cancel()

        if self._sandbox_wrapped_run_loop_task and not self._sandbox_wrapped_run_loop_task.done():
            self._sandbox_wrapped_run_loop_task.cancel()

        if self._input_guardrails_task and not self._input_guardrails_task.done():
            self._input_guardrails_task.cancel()

        if self._output_guardrails_task and not self._output_guardrails_task.done():
            self._output_guardrails_task.cancel()

    def __str__(self) -> str:
        return pretty_print_run_result_streaming(self)

    async def _await_task_safely(self, task: asyncio.Task[Any] | None) -> None:
        """Wait for a task, leaving its cancellation and exceptions to _check_errors().

        This ensures we do not lose late guardrail exceptions while not surfacing the task's
        CancelledError to callers of stream_events. Consumer cancellation still propagates.
        """
        if task and not task.done():
            try:
                # Waiting directly would conflate child cancellation with consumer cancellation.
                await asyncio.wait((task,))
            except asyncio.CancelledError:
                task.cancel()
                # Preserve direct-await settlement before the consumer releases owned resources.
                await asyncio.wait((task,))
                raise

    def _drain_event_queue(self) -> None:
        """Remove any pending items from the event queue and mark them done."""
        while not self._event_queue.empty():
            try:
                self._event_queue.get_nowait()
                self._event_queue.task_done()
            except asyncio.QueueEmpty:
                break
            except ValueError:
                # task_done called too many times; nothing more to drain.
                break

    def _drain_input_guardrail_queue(self) -> None:
        """Remove any pending items from the input guardrail queue."""
        while not self._input_guardrail_queue.empty():
            try:
                self._input_guardrail_queue.get_nowait()
            except asyncio.QueueEmpty:
                break

    def to_state(self) -> RunState[Any]:
        """Create a RunState from this streaming result to resume execution.

        This is useful when the run was interrupted (e.g., for tool approval). You can
        approve or reject the tool calls on the returned state, then pass it back to
        `Runner.run_streamed()` to continue execution.

        Returns:
            A RunState that can be used to resume the run.

        Example:
            ```python
            # Run agent until it needs approval
            result = Runner.run_streamed(agent, "Use the delete_file tool")
            async for event in result.stream_events():
                pass

            if result.interruptions:
                # Approve the tool call
                state = result.to_state()
                state.approve(result.interruptions[0])

                # Resume the run
                result = Runner.run_streamed(agent, state)
                async for event in result.stream_events():
                    pass
            ```
        """
        # Create a RunState from the current result
        # Use _original_input (updated on handoffs/resume when input history changes).
        # This avoids serializing a mutated view of input history.
        state = RunState(
            context=self.context_wrapper._copy_for_run_state(),
            original_input=self._original_input if self._original_input is not None else self.input,
            starting_agent=_starting_agent_for_state(self),
            max_turns=self.max_turns,
        )

        state = _populate_state_from_result(
            state,
            self,
            current_turn=self.current_turn,
            last_processed_response=self._last_processed_response,
            current_turn_persisted_item_count=self._current_turn_persisted_item_count,
            tool_use_tracker_snapshot=self._tool_use_tracker_snapshot,
            conversation_id=self._conversation_id,
            previous_response_id=self._previous_response_id,
            auto_previous_response_id=self._auto_previous_response_id,
        )
        _copy_pending_nested_agent_tool_states(state, self)
        return state
